import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Documents table
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isTemplate: boolean("is_template").default(false),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Financial records table
export const financialRecords = pgTable("financial_records", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => documents.id),
  data: json("data").notNull(), // For storing table data
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Media table for images and locations
export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").references(() => documents.id),
  type: text("type").notNull(), // 'image' or 'location'
  url: text("url"),
  metadata: json("metadata"), // For storing location data or image details
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  title: true,
  content: true,
  isTemplate: true,
  userId: true,
});

export const insertFinancialRecordSchema = createInsertSchema(financialRecords).pick({
  documentId: true,
  data: true,
});

export const insertMediaSchema = createInsertSchema(media).pick({
  documentId: true,
  type: true,
  url: true,
  metadata: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type FinancialRecord = typeof financialRecords.$inferSelect;
export type InsertFinancialRecord = z.infer<typeof insertFinancialRecordSchema>;

export type Media = typeof media.$inferSelect;
export type InsertMedia = z.infer<typeof insertMediaSchema>;
