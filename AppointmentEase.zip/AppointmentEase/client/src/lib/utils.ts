import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { DocumentTable, TableCell } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Utility function to generate a unique ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Create a new empty table structure
export function createTableStructure(rows: number, columns: number): DocumentTable {
  const cells: TableCell[][] = [];

  for (let i = 0; i < rows; i++) {
    const row: TableCell[] = [];
    for (let j = 0; j < columns; j++) {
      row.push({
        id: generateId(),
        content: '',
        style: {}
      });
    }
    cells.push(row);
  }

  return {
    rows,
    columns,
    cells
  };
}

// Function to evaluate a simple formula
export function evaluateFormula(formula: string, tableData: TableCell[][]): number {
  // Remove the '=' prefix
  const expression = formula.substring(1).trim();
  
  // Handle SUM
  if (expression.startsWith("SUM(") && expression.endsWith(")")) {
    const range = expression.substring(4, expression.length - 1);
    const cells = range.split(",").map(r => r.trim());
    
    let sum = 0;
    for (const cell of cells) {
      const value = getCellValue(cell, tableData);
      if (!isNaN(value)) {
        sum += value;
      }
    }
    return sum;
  }
  
  // Handle simple arithmetic expressions
  if (expression.includes("+") || expression.includes("-") || 
      expression.includes("*") || expression.includes("/")) {
    
    // Replace cell references with values
    const regex = /[A-Z]+[0-9]+/g;
    let evalExpression = expression;
    const cellRefs = expression.match(regex) || [];
    
    for (const cellRef of cellRefs) {
      const value = getCellValue(cellRef, tableData);
      evalExpression = evalExpression.replace(cellRef, value.toString());
    }
    
    try {
      // Using Function constructor to evaluate the expression
      // This is safer than eval
      return new Function(`return ${evalExpression}`)();
    } catch (error) {
      console.error("Error evaluating formula:", error);
      return 0;
    }
  }
  
  return 0;
}

// Get the value of a cell by reference (e.g., "A1", "B2")
function getCellValue(cellRef: string, tableData: TableCell[][]): number {
  const colLetterMatch = cellRef.match(/[A-Z]+/);
  const rowNumberMatch = cellRef.match(/[0-9]+/);
  
  if (!colLetterMatch || !rowNumberMatch) return 0;
  
  const colLetter = colLetterMatch[0];
  const rowNumber = parseInt(rowNumberMatch[0]) - 1; // 0-based index
  
  // Convert column letter to index (A=0, B=1, ...)
  let colIndex = 0;
  for (let i = 0; i < colLetter.length; i++) {
    colIndex = colIndex * 26 + (colLetter.charCodeAt(i) - 'A'.charCodeAt(0));
  }
  
  // Get the cell value
  if (rowNumber >= 0 && rowNumber < tableData.length &&
      colIndex >= 0 && colIndex < tableData[0].length) {
    const content = tableData[rowNumber][colIndex].content;
    return parseFloat(content) || 0;
  }
  
  return 0;
}

// Convert HTML content to plain text
export function htmlToPlainText(html: string): string {
  const temp = document.createElement('div');
  temp.innerHTML = html;
  return temp.textContent || temp.innerText || '';
}

// Function to safely parse JSON
export function safeJSONParse(str: string, fallback: any = null) {
  try {
    return JSON.parse(str);
  } catch (e) {
    return fallback;
  }
}

// Convert CSS pixel values to pt for print/export
export function pxToPt(px: number): number {
  return px * 0.75;
}

// Function to determine if a string contains RTL characters
export function containsRTL(text: string): boolean {
  const rtlChars = /[\u0591-\u07FF\u200F\u202B\u202E\uFB1D-\uFDFD\uFE70-\uFEFC]/;
  return rtlChars.test(text);
}

// Function to sanitize content before saving
export function sanitizeContent(content: string): string {
  const div = document.createElement('div');
  div.innerHTML = content;
  
  // Remove any script tags
  const scripts = div.querySelectorAll('script');
  scripts.forEach(script => script.remove());
  
  // Remove any on* attributes
  const allElements = div.querySelectorAll('*');
  allElements.forEach(el => {
    [...el.attributes].forEach(attr => {
      if (attr.name.startsWith('on')) {
        el.removeAttribute(attr.name);
      }
    });
  });
  
  return div.innerHTML;
}
