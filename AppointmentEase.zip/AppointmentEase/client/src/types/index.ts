export interface DocumentElement {
  id: string;
  type: 'text' | 'table' | 'image' | 'location' | 'dropdown';
  content: any;
  style?: Record<string, string>;
}

export interface DocumentTable {
  rows: number;
  columns: number;
  cells: TableCell[][];
  style?: Record<string, string>;
}

export interface TableCell {
  id: string;
  content: string;
  colSpan?: number;
  rowSpan?: number;
  formula?: string;
  hasDropdown?: boolean;
  dropdownOptions?: string[];
  style?: Record<string, string>;
}

export interface Document {
  id: string;
  title: string;
  content: string;
  isTemplate: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: number;
  username: string;
}

export interface InsertDocument {
  title: string;
  content: string;
  isTemplate: boolean;
}

export interface EditorState {
  currentDocument: Document | null;
  undoStack: string[];
  redoStack: string[];
  selectedElement: string | null;
  textDirection: 'rtl' | 'ltr';
  fontFamily: string;
  fontSize: string;
  isBold: boolean;
  isItalic: boolean;
  isUnderline: boolean;
  documentChanged: boolean;
}

export interface LocationData {
  lat: number;
  lng: number;
  name?: string;
  source: 'google' | 'telegram' | 'coordinates';
}
