import { useState, useCallback } from 'react';

interface UndoRedoState<T> {
  past: T[];
  present: T;
  future: T[];
}

interface UndoRedoResult<T> {
  state: T;
  setState: (newState: T) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  resetHistory: () => void;
}

export function useUndoRedo<T>(initialState: T): UndoRedoResult<T> {
  const [state, setInternalState] = useState<UndoRedoState<T>>({
    past: [],
    present: initialState,
    future: [],
  });

  const canUndo = state.past.length > 0;
  const canRedo = state.future.length > 0;

  // Set state with history tracking
  const setState = useCallback((newState: T) => {
    setInternalState(prevState => ({
      past: [...prevState.past, prevState.present],
      present: newState,
      future: [],
    }));
  }, []);

  // Undo the last action
  const undo = useCallback(() => {
    if (!canUndo) return;

    setInternalState(prevState => {
      const previous = prevState.past[prevState.past.length - 1];
      const newPast = prevState.past.slice(0, prevState.past.length - 1);

      return {
        past: newPast,
        present: previous,
        future: [prevState.present, ...prevState.future],
      };
    });
  }, [canUndo]);

  // Redo the last undone action
  const redo = useCallback(() => {
    if (!canRedo) return;

    setInternalState(prevState => {
      const next = prevState.future[0];
      const newFuture = prevState.future.slice(1);

      return {
        past: [...prevState.past, prevState.present],
        present: next,
        future: newFuture,
      };
    });
  }, [canRedo]);

  // Reset history
  const resetHistory = useCallback(() => {
    setInternalState({
      past: [],
      present: state.present,
      future: [],
    });
  }, [state.present]);

  return {
    state: state.present,
    setState,
    undo,
    redo,
    canUndo,
    canRedo,
    resetHistory,
  };
}
