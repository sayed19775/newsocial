import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { nanoid } from 'nanoid';
import { 
  DocumentContent, 
  DocumentContentBlock, 
  TextBlock, 
  TableBlock, 
  ImageBlock, 
  LocationBlock, 
  CheckboxBlock,
  TableRow,
  TableCell,
  documentContentSchema
} from '@shared/schema';
import { useUndoRedo } from '@/hooks/useUndoRedo';

// Default empty document
const defaultDocument: DocumentContent = {
  blocks: [],
  direction: 'rtl',
  title: 'مستند جديد',
};

interface DocumentContextType {
  documentState: DocumentContent;
  documentId: number | null;
  isTemplate: boolean;
  setDocumentId: (id: number | null) => void;
  setIsTemplate: (isTemplate: boolean) => void;
  setTitle: (title: string) => void;
  setDirection: (direction: 'rtl' | 'ltr') => void;
  addBlock: (block: DocumentContentBlock) => void;
  updateBlock: (id: string, block: Partial<DocumentContentBlock>) => void;
  removeBlock: (id: string) => void;
  moveBlockUp: (id: string) => void;
  moveBlockDown: (id: string) => void;
  resetDocument: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  isDirty: boolean;
  setIsDirty: (isDirty: boolean) => void;
  
  // Text block specific functions
  addTextBlock: (content?: string, direction?: 'rtl' | 'ltr') => void;
  
  // Table block specific functions
  addTableBlock: (rows: number, cols: number) => void;
  updateTableCell: (tableId: string, rowIndex: number, colIndex: number, data: Partial<TableCell>) => void;
  addTableRow: (tableId: string, rowIndex: number) => void;
  removeTableRow: (tableId: string, rowIndex: number) => void;
  addTableColumn: (tableId: string, columnIndex: number) => void;
  removeTableColumn: (tableId: string, columnIndex: number) => void;
  
  // Image block specific functions
  addImageBlock: (src: string, alt?: string) => void;
  
  // Location block specific functions
  addLocationBlock: (latitude: string, longitude: string, address?: string) => void;
  
  // Checkbox block specific functions
  addCheckboxBlock: (label: string, checked?: boolean) => void;
}

export const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

interface DocumentProviderProps {
  children: ReactNode;
}

export const DocumentProvider = ({ children }: DocumentProviderProps) => {
  const [documentState, setDocumentState] = useState<DocumentContent>(defaultDocument);
  const [documentId, setDocumentId] = useState<number | null>(null);
  const [isTemplate, setIsTemplate] = useState<boolean>(false);
  const [isDirty, setIsDirty] = useState<boolean>(false);
  
  const { 
    state, 
    setState, 
    undo, 
    redo, 
    canUndo, 
    canRedo, 
    resetHistory 
  } = useUndoRedo<DocumentContent>(documentState);
  
  // Update the document state when the undoable state changes
  useEffect(() => {
    setDocumentState(state);
  }, [state]);
  
  // Reset the document to empty state
  const resetDocument = () => {
    setState(defaultDocument);
    resetHistory();
    setDocumentId(null);
    setIsTemplate(false);
    setIsDirty(false);
  };
  
  // Update document title
  const setTitle = (title: string) => {
    setState({ ...state, title });
    setIsDirty(true);
  };
  
  // Update document direction
  const setDirection = (direction: 'rtl' | 'ltr') => {
    setState({ ...state, direction });
    setIsDirty(true);
  };
  
  // Add a new block to the document
  const addBlock = (block: DocumentContentBlock) => {
    setState({ 
      ...state, 
      blocks: [...state.blocks, block] 
    });
    setIsDirty(true);
  };
  
  // Update an existing block
  const updateBlock = (id: string, updatedBlockData: Partial<DocumentContentBlock>) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => 
        block.id === id ? { ...block, ...updatedBlockData } : block
      )
    });
    setIsDirty(true);
  };
  
  // Remove a block
  const removeBlock = (id: string) => {
    setState({
      ...state,
      blocks: state.blocks.filter(block => block.id !== id)
    });
    setIsDirty(true);
  };
  
  // Move a block up
  const moveBlockUp = (id: string) => {
    const blocks = [...state.blocks];
    const index = blocks.findIndex(block => block.id === id);
    if (index > 0) {
      const temp = blocks[index - 1];
      blocks[index - 1] = blocks[index];
      blocks[index] = temp;
      setState({ ...state, blocks });
      setIsDirty(true);
    }
  };
  
  // Move a block down
  const moveBlockDown = (id: string) => {
    const blocks = [...state.blocks];
    const index = blocks.findIndex(block => block.id === id);
    if (index < blocks.length - 1) {
      const temp = blocks[index + 1];
      blocks[index + 1] = blocks[index];
      blocks[index] = temp;
      setState({ ...state, blocks });
      setIsDirty(true);
    }
  };
  
  // Add a text block
  const addTextBlock = (content = '', direction: 'rtl' | 'ltr' = 'rtl') => {
    const newTextBlock: TextBlock = {
      id: nanoid(),
      type: 'text',
      content,
      direction,
      fontFamily: 'Times New Roman',
      fontSize: 14,
      fontWeight: 'normal',
    };
    
    addBlock(newTextBlock);
  };
  
  // Add a table block
  const addTableBlock = (rows: number, cols: number) => {
    const tableRows: TableRow[] = [];
    
    for (let i = 0; i < rows; i++) {
      const cells: TableCell[] = [];
      
      for (let j = 0; j < cols; j++) {
        cells.push({
          id: nanoid(),
          content: '',
          rowSpan: 1,
          colSpan: 1,
          direction: 'rtl',
          fontFamily: 'Times New Roman',
          fontSize: 14,
          fontWeight: 'normal',
        });
      }
      
      tableRows.push({
        id: nanoid(),
        cells,
      });
    }
    
    const newTableBlock: TableBlock = {
      id: nanoid(),
      type: 'table',
      rows: tableRows,
    };
    
    addBlock(newTableBlock);
  };
  
  // Update a table cell
  const updateTableCell = (tableId: string, rowIndex: number, colIndex: number, data: Partial<TableCell>) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => {
        if (block.id === tableId && block.type === 'table') {
          const updatedRows = [...block.rows];
          const cells = [...updatedRows[rowIndex].cells];
          cells[colIndex] = { ...cells[colIndex], ...data };
          updatedRows[rowIndex] = { ...updatedRows[rowIndex], cells };
          return { ...block, rows: updatedRows };
        }
        return block;
      })
    });
    setIsDirty(true);
  };
  
  // Add a table row
  const addTableRow = (tableId: string, rowIndex: number) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => {
        if (block.id === tableId && block.type === 'table') {
          const updatedRows = [...block.rows];
          const columnCount = updatedRows[0].cells.length;
          
          const newCells: TableCell[] = [];
          for (let i = 0; i < columnCount; i++) {
            newCells.push({
              id: nanoid(),
              content: '',
              rowSpan: 1,
              colSpan: 1,
              direction: 'rtl',
              fontFamily: 'Times New Roman',
              fontSize: 14,
              fontWeight: 'normal',
            });
          }
          
          updatedRows.splice(rowIndex + 1, 0, {
            id: nanoid(),
            cells: newCells,
          });
          
          return { ...block, rows: updatedRows };
        }
        return block;
      })
    });
    setIsDirty(true);
  };
  
  // Remove a table row
  const removeTableRow = (tableId: string, rowIndex: number) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => {
        if (block.id === tableId && block.type === 'table') {
          if (block.rows.length <= 1) {
            return block; // Don't remove the last row
          }
          
          const updatedRows = [...block.rows];
          updatedRows.splice(rowIndex, 1);
          return { ...block, rows: updatedRows };
        }
        return block;
      })
    });
    setIsDirty(true);
  };
  
  // Add a table column
  const addTableColumn = (tableId: string, columnIndex: number) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => {
        if (block.id === tableId && block.type === 'table') {
          const updatedRows = block.rows.map(row => {
            const updatedCells = [...row.cells];
            updatedCells.splice(columnIndex + 1, 0, {
              id: nanoid(),
              content: '',
              rowSpan: 1,
              colSpan: 1,
              direction: 'rtl',
              fontFamily: 'Times New Roman',
              fontSize: 14,
              fontWeight: 'normal',
            });
            return { ...row, cells: updatedCells };
          });
          return { ...block, rows: updatedRows };
        }
        return block;
      })
    });
    setIsDirty(true);
  };
  
  // Remove a table column
  const removeTableColumn = (tableId: string, columnIndex: number) => {
    setState({
      ...state,
      blocks: state.blocks.map(block => {
        if (block.id === tableId && block.type === 'table') {
          if (block.rows[0].cells.length <= 1) {
            return block; // Don't remove the last column
          }
          
          const updatedRows = block.rows.map(row => {
            const updatedCells = [...row.cells];
            updatedCells.splice(columnIndex, 1);
            return { ...row, cells: updatedCells };
          });
          return { ...block, rows: updatedRows };
        }
        return block;
      })
    });
    setIsDirty(true);
  };
  
  // Add an image block
  const addImageBlock = (src: string, alt = '') => {
    const newImageBlock: ImageBlock = {
      id: nanoid(),
      type: 'image',
      src,
      alt,
      width: 300,
      height: 200,
    };
    
    addBlock(newImageBlock);
  };
  
  // Add a location block
  const addLocationBlock = (latitude: string, longitude: string, address = '') => {
    const newLocationBlock: LocationBlock = {
      id: nanoid(),
      type: 'location',
      latitude,
      longitude,
      address,
    };
    
    addBlock(newLocationBlock);
  };
  
  // Add a checkbox block
  const addCheckboxBlock = (label: string, checked = false) => {
    const newCheckboxBlock: CheckboxBlock = {
      id: nanoid(),
      type: 'checkbox',
      label,
      checked,
      excludeFromPrint: false,
    };
    
    addBlock(newCheckboxBlock);
  };
  
  return (
    <DocumentContext.Provider value={{
      documentState,
      documentId,
      isTemplate,
      setDocumentId,
      setIsTemplate,
      setTitle,
      setDirection,
      addBlock,
      updateBlock,
      removeBlock,
      moveBlockUp,
      moveBlockDown,
      resetDocument,
      undo,
      redo,
      canUndo,
      canRedo,
      isDirty,
      setIsDirty,
      addTextBlock,
      addTableBlock,
      updateTableCell,
      addTableRow,
      removeTableRow,
      addTableColumn,
      removeTableColumn,
      addImageBlock,
      addLocationBlock,
      addCheckboxBlock,
    }}>
      {children}
    </DocumentContext.Provider>
  );
};

export const useDocument = () => {
  const context = useContext(DocumentContext);
  if (context === undefined) {
    throw new Error('useDocument must be used within a DocumentProvider');
  }
  return context;
};
