import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { EditorState, Document } from '@/types';
import { sanitizeContent } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Define the initial state
const initialState: EditorState = {
  currentDocument: null,
  undoStack: [],
  redoStack: [],
  selectedElement: null,
  textDirection: 'rtl',
  fontFamily: 'times-new-roman',
  fontSize: '14',
  isBold: false,
  isItalic: false,
  isUnderline: false,
  documentChanged: false
};

// Define the action types
type EditorAction =
  | { type: 'SET_DOCUMENT'; payload: Document }
  | { type: 'UPDATE_DOCUMENT_CONTENT'; payload: string }
  | { type: 'ADD_TO_UNDO_STACK'; payload: string }
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | { type: 'SET_SELECTED_ELEMENT'; payload: string | null }
  | { type: 'SET_TEXT_DIRECTION'; payload: 'rtl' | 'ltr' }
  | { type: 'SET_FONT_FAMILY'; payload: string }
  | { type: 'SET_FONT_SIZE'; payload: string }
  | { type: 'TOGGLE_BOLD' }
  | { type: 'TOGGLE_ITALIC' }
  | { type: 'TOGGLE_UNDERLINE' }
  | { type: 'SET_DOCUMENT_CHANGED'; payload: boolean }
  | { type: 'RESET_EDITOR' };

// Define the context type
interface EditorContextType {
  state: EditorState;
  dispatch: React.Dispatch<EditorAction>;
  saveDocument: (isTemplate: boolean) => Promise<void>;
  loadDocument: (id: string) => Promise<void>;
  createNewDocument: () => void;
}

// Create the context
const EditorContext = createContext<EditorContextType | undefined>(undefined);

// Create the reducer
function editorReducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case 'SET_DOCUMENT':
      return {
        ...state,
        currentDocument: action.payload,
        undoStack: [],
        redoStack: [],
        documentChanged: false
      };
    case 'UPDATE_DOCUMENT_CONTENT':
      if (!state.currentDocument) return state;
      return {
        ...state,
        currentDocument: {
          ...state.currentDocument,
          content: action.payload
        },
        documentChanged: true
      };
    case 'ADD_TO_UNDO_STACK':
      if (!state.currentDocument) return state;
      return {
        ...state,
        undoStack: [...state.undoStack, action.payload],
        documentChanged: true
      };
    case 'UNDO':
      if (state.undoStack.length === 0 || !state.currentDocument) return state;
      const lastContent = state.undoStack[state.undoStack.length - 1];
      const newUndoStack = state.undoStack.slice(0, -1);
      
      // Update the editor's content directly
      const editor = document.getElementById('documentEditor');
      if (editor) {
        editor.innerHTML = lastContent;
      }
      
      return {
        ...state,
        undoStack: newUndoStack,
        redoStack: [state.currentDocument.content, ...state.redoStack],
        currentDocument: {
          ...state.currentDocument,
          content: lastContent
        },
        documentChanged: true
      };
    case 'REDO':
      if (state.redoStack.length === 0 || !state.currentDocument) return state;
      const [redoContent, ...restRedoStack] = state.redoStack;
      
      // Update the editor's content directly
      const editorElement = document.getElementById('documentEditor');
      if (editorElement) {
        editorElement.innerHTML = redoContent;
      }
      
      return {
        ...state,
        undoStack: [...state.undoStack, state.currentDocument.content],
        redoStack: restRedoStack,
        currentDocument: {
          ...state.currentDocument,
          content: redoContent
        },
        documentChanged: true
      };
    case 'SET_SELECTED_ELEMENT':
      return {
        ...state,
        selectedElement: action.payload
      };
    case 'SET_TEXT_DIRECTION':
      return {
        ...state,
        textDirection: action.payload
      };
    case 'SET_FONT_FAMILY':
      return {
        ...state,
        fontFamily: action.payload
      };
    case 'SET_FONT_SIZE':
      return {
        ...state,
        fontSize: action.payload
      };
    case 'TOGGLE_BOLD':
      return {
        ...state,
        isBold: !state.isBold
      };
    case 'TOGGLE_ITALIC':
      return {
        ...state,
        isItalic: !state.isItalic
      };
    case 'TOGGLE_UNDERLINE':
      return {
        ...state,
        isUnderline: !state.isUnderline
      };
    case 'SET_DOCUMENT_CHANGED':
      return {
        ...state,
        documentChanged: action.payload
      };
    case 'RESET_EDITOR':
      return {
        ...initialState
      };
    default:
      return state;
  }
}

// Create the provider component
export const EditorProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(editorReducer, initialState);
  const { toast } = useToast();

  // Function to save the document
  const saveDocument = async (isTemplate: boolean) => {
    try {
      if (!state.currentDocument) {
        // Create new document
        const newDoc = {
          title: 'New Document',
          content: state.currentDocument?.content || '<div dir="rtl"></div>',
          isTemplate
        };
        
        const response = await apiRequest('POST', '/api/documents', newDoc);
        const savedDoc = await response.json();
        
        dispatch({ type: 'SET_DOCUMENT', payload: savedDoc });
        dispatch({ type: 'SET_DOCUMENT_CHANGED', payload: false });
        
        toast({
          title: 'Document saved',
          description: 'Your document has been saved successfully.',
        });
      } else {
        // Update existing document
        const updatedDoc = {
          ...state.currentDocument,
          content: sanitizeContent(state.currentDocument.content),
          isTemplate
        };
        
        await apiRequest('PUT', `/api/documents/${state.currentDocument.id}`, updatedDoc);
        
        dispatch({ 
          type: 'SET_DOCUMENT', 
          payload: {
            ...state.currentDocument,
            isTemplate,
            updatedAt: new Date().toISOString()
          }
        });
        dispatch({ type: 'SET_DOCUMENT_CHANGED', payload: false });
        
        toast({
          title: isTemplate ? 'Template saved' : 'Document saved',
          description: isTemplate ? 'Your template has been saved successfully.' : 'Your document has been saved successfully.',
        });
      }
    } catch (error) {
      console.error('Error saving document:', error);
      toast({
        title: 'Error',
        description: 'There was an error saving your document.',
        variant: 'destructive',
      });
    }
  };

  // Function to load a document
  const loadDocument = async (id: string) => {
    try {
      const response = await apiRequest('GET', `/api/documents/${id}`, undefined);
      const document = await response.json();
      
      dispatch({ type: 'SET_DOCUMENT', payload: document });
      
      toast({
        title: 'Document loaded',
        description: 'Your document has been loaded successfully.',
      });
    } catch (error) {
      console.error('Error loading document:', error);
      toast({
        title: 'Error',
        description: 'There was an error loading your document.',
        variant: 'destructive',
      });
    }
  };

  // Function to create a new document
  const createNewDocument = () => {
    const newDocument: Document = {
      id: 'temp',
      title: 'New Document',
      content: '<div dir="rtl" class="times-new-roman" style="font-size: 14px;"></div>',
      isTemplate: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    dispatch({ type: 'SET_DOCUMENT', payload: newDocument });
  };

  // Auto-save feature
  useEffect(() => {
    const autoSaveInterval = 30000; // 30 seconds
    
    const autoSave = async () => {
      if (state.documentChanged && state.currentDocument && state.currentDocument.id !== 'temp') {
        try {
          const updatedDoc = {
            ...state.currentDocument,
            content: sanitizeContent(state.currentDocument.content)
          };
          
          await apiRequest('PUT', `/api/documents/${state.currentDocument.id}`, updatedDoc);
          dispatch({ type: 'SET_DOCUMENT_CHANGED', payload: false });
          
          console.log('Auto-saved document');
        } catch (error) {
          console.error('Error auto-saving document:', error);
        }
      }
    };
    
    const intervalId = setInterval(autoSave, autoSaveInterval);
    
    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, [state.documentChanged, state.currentDocument]);

  return (
    <EditorContext.Provider value={{ state, dispatch, saveDocument, loadDocument, createNewDocument }}>
      {children}
    </EditorContext.Provider>
  );
};

// Create a hook to use the editor context
export const useEditor = (): EditorContextType => {
  const context = useContext(EditorContext);
  if (context === undefined) {
    throw new Error('useEditor must be used within an EditorProvider');
  }
  return context;
};
