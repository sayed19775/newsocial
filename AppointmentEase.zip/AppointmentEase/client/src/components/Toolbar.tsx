import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar, FileDown, FileUp, Pen, Table, List, MapPin, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, AlignJustify, CheckSquare, Image, Settings } from 'lucide-react';
import { useEditor } from '@/contexts/EditorContext';
import TableModal from '@/components/modals/TableModal';
import DropdownModal from '@/components/modals/DropdownModal';
import LocationModal from '@/components/modals/LocationModal';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function Toolbar() {
  const { state, dispatch } = useEditor();
  const [showTableModal, setShowTableModal] = useState(false);
  
  // Handle direct table insertion (when modal doesn't work)
  const handleDirectTableInsertion = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    // Create a div container for table operations
    const tableContainer = document.createElement('div');
    tableContainer.className = 'relative table-container';
    tableContainer.dataset.type = 'table-container';
    
    // Create a simple table with 3 rows and 3 columns
    const table = document.createElement('table');
    table.className = 'document-table';
    
    // Create table body
    const tbody = document.createElement('tbody');
    
    // Create header row
    const headerRow = document.createElement('tr');
    for (let i = 0; i < 3; i++) {
      const th = document.createElement('th');
      th.textContent = `عنوان ${i+1}`;
      th.contentEditable = 'true';
      headerRow.appendChild(th);
    }
    tbody.appendChild(headerRow);
    
    // Create data rows
    for (let i = 0; i < 2; i++) {
      const tr = document.createElement('tr');
      
      for (let j = 0; j < 3; j++) {
        const td = document.createElement('td');
        td.contentEditable = 'true';
        td.textContent = `صف ${i+1}، عمود ${j+1}`;
        
        // Add cell click handler
        td.addEventListener('dblclick', () => {
          // Make sure it's editable
          td.contentEditable = 'true';
          td.focus();
        });
        
        tr.appendChild(td);
      }
      
      tbody.appendChild(tr);
    }
    
    table.appendChild(tbody);
    tableContainer.appendChild(table);
    
    // Add table controls for adding rows and columns
    const tableControls = document.createElement('div');
    tableControls.className = 'table-controls absolute right-0 top-0 flex flex-col bg-white border rounded shadow-sm';
    tableControls.style.transform = 'translateX(100%)';
    tableControls.style.display = 'none';
    
    // Add row button
    const addRowBtn = document.createElement('button');
    addRowBtn.textContent = 'إضافة صف';
    addRowBtn.className = 'px-2 py-1 text-xs hover:bg-gray-100';
    addRowBtn.addEventListener('click', () => {
      const rowCount = table.rows.length;
      const colCount = table.rows[0].cells.length;
      
      const newRow = document.createElement('tr');
      for (let i = 0; i < colCount; i++) {
        const td = document.createElement('td');
        td.contentEditable = 'true';
        newRow.appendChild(td);
      }
      
      tbody.appendChild(newRow);
      
      // Update document content
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
    });
    
    // Add column button
    const addColBtn = document.createElement('button');
    addColBtn.textContent = 'إضافة عمود';
    addColBtn.className = 'px-2 py-1 text-xs hover:bg-gray-100';
    addColBtn.addEventListener('click', () => {
      const rows = table.rows;
      
      for (let i = 0; i < rows.length; i++) {
        const cell = i === 0 ? document.createElement('th') : document.createElement('td');
        cell.contentEditable = 'true';
        rows[i].appendChild(cell);
      }
      
      // Update document content
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
    });
    
    // Add delete table button
    const deleteTableBtn = document.createElement('button');
    deleteTableBtn.textContent = 'حذف الجدول';
    deleteTableBtn.className = 'px-2 py-1 text-xs text-white bg-red-500 hover:bg-red-600';
    deleteTableBtn.addEventListener('click', () => {
      if (confirm('هل أنت متأكد من حذف هذا الجدول؟')) {
        // Save current content to undo stack
        dispatch({ 
          type: 'ADD_TO_UNDO_STACK', 
          payload: editor.innerHTML 
        });
        
        // Remove the table container
        tableContainer.remove();
        
        // Update document content
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
        
        toast({
          title: 'تم حذف الجدول',
          description: 'تم حذف الجدول بنجاح.',
        });
      }
    });
    
    tableControls.appendChild(addRowBtn);
    tableControls.appendChild(addColBtn);
    tableControls.appendChild(deleteTableBtn);
    tableContainer.appendChild(tableControls);
    
    // Show controls on hover
    tableContainer.addEventListener('mouseenter', () => {
      tableControls.style.display = 'flex';
    });
    
    tableContainer.addEventListener('mouseleave', () => {
      tableControls.style.display = 'none';
    });
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert the table at the cursor position or at the end
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(tableContainer);
    } else {
      // Insert at end if no selection
      editor.appendChild(tableContainer);
    }
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
    
    toast({
      title: 'تم إدراج الجدول',
      description: 'تم إدراج جدول قابل للتعديل. يمكنك النقر المزدوج على أي خلية لتعديلها.',
    });
  };
  const [showDropdownModal, setShowDropdownModal] = useState(false);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const { toast } = useToast();
  
  // Function to convert Gregorian to Hijri
  const gregorianToHijri = (date: Date): string => {
    // This is a simple implementation. For more accurate conversions,
    // a proper library like moment-hijri would be better.
    const gregorianYear = date.getFullYear();
    const gregorianMonth = date.getMonth();
    const gregorianDay = date.getDate();
    
    // Approximate conversion (based on simplified algorithm)
    let hijriYear = Math.floor(gregorianYear - 622 + (gregorianYear - 622) / 32);
    let hijriMonth = ((gregorianMonth + 1) + 1) % 12;
    if (hijriMonth === 0) hijriMonth = 12;
    let hijriDay = gregorianDay;
    
    return `${hijriYear}/${hijriMonth}/${hijriDay}`;
  };
  
  // Handle date insertion with both Gregorian and Hijri
  const handleInsertDate = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    // Add current date in yyyy-mm-dd format
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    
    // Format dates
    const gregorianDate = `${year}-${month}-${day}`;
    const hijriDate = gregorianToHijri(now);
    
    // Create a container for the dates
    const dateContainer = document.createElement('div');
    dateContainer.className = 'date-container';
    dateContainer.style.margin = '10px 0';
    dateContainer.style.padding = '5px';
    dateContainer.style.border = '1px solid #eee';
    dateContainer.style.borderRadius = '4px';
    dateContainer.style.backgroundColor = '#f9f9f9';
    
    // Create a span for the Gregorian date
    const gregorianSpan = document.createElement('span');
    gregorianSpan.className = 'gregorian-date';
    gregorianSpan.textContent = `التاريخ الميلادي: ${gregorianDate}`;
    gregorianSpan.style.fontFamily = state.fontFamily;
    gregorianSpan.style.fontSize = `${state.fontSize}px`;
    gregorianSpan.style.display = 'block';
    gregorianSpan.style.marginBottom = '5px';
    
    // Create a span for the Hijri date
    const hijriSpan = document.createElement('span');
    hijriSpan.className = 'hijri-date';
    hijriSpan.textContent = `التاريخ الهجري: ${hijriDate}`;
    hijriSpan.style.fontFamily = state.fontFamily;
    hijriSpan.style.fontSize = `${state.fontSize}px`;
    hijriSpan.style.display = 'block';
    
    // Add dates to container
    dateContainer.appendChild(gregorianSpan);
    dateContainer.appendChild(hijriSpan);
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert at cursor position
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(dateContainer);
    } else {
      editor.appendChild(dateContainer);
    }
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
    
    toast({
      title: 'تم إدراج التاريخ',
      description: 'تم إدراج التاريخ الميلادي والهجري.',
    });
  };

  // Handle text insertion
  const handleInsertText = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor) return;

    const p = document.createElement('p');
    p.textContent = 'أدخل النص هنا';
    p.dir = state.textDirection;
    p.className = state.fontFamily;
    p.style.fontSize = `${state.fontSize}px`;
    p.style.fontWeight = state.isBold ? 'bold' : 'normal';
    p.style.fontStyle = state.isItalic ? 'italic' : 'normal';
    p.style.textDecoration = state.isUnderline ? 'underline' : 'none';
    
    // Save current content to undo stack
    if (state.currentDocument) {
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
    }
    
    // Insert the new paragraph
    editor.appendChild(p);
    
    // Update document content
    if (state.currentDocument) {
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
    }
  };

  // Handle text direction
  const handleTextDirection = (direction: 'rtl' | 'ltr') => {
    dispatch({ type: 'SET_TEXT_DIRECTION', payload: direction });
    
    // Apply to selection if there is one
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const span = document.createElement('span');
      span.dir = direction;
      
      try {
        range.surroundContents(span);
        
        // Update document content
        const editor = document.getElementById('documentEditor');
        if (editor && state.currentDocument) {
          dispatch({ 
            type: 'ADD_TO_UNDO_STACK', 
            payload: state.currentDocument.content 
          });
          dispatch({ 
            type: 'UPDATE_DOCUMENT_CONTENT', 
            payload: editor.innerHTML 
          });
        }
      } catch (e) {
        console.error('Error applying text direction:', e);
      }
    }
  };

  // Handle font family change
  const handleFontFamilyChange = (value: string) => {
    dispatch({ type: 'SET_FONT_FAMILY', payload: value });
    
    // Apply to selection if there is one
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      document.execCommand('fontName', false, value);
      
      // Update document content
      const editor = document.getElementById('documentEditor');
      if (editor && state.currentDocument) {
        dispatch({ 
          type: 'ADD_TO_UNDO_STACK', 
          payload: state.currentDocument.content 
        });
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }
    }
  };

  // Handle font size change
  const handleFontSizeChange = (value: string) => {
    dispatch({ type: 'SET_FONT_SIZE', payload: value });
    
    // Apply to selection if there is one
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      
      // Create a span with the desired font size
      const span = document.createElement('span');
      span.style.fontSize = `${value}px`;
      
      try {
        // Wrap the selected content with the span
        range.surroundContents(span);
      } catch (e) {
        // If we can't surround (e.g., selection spans multiple blocks),
        // apply the style directly to existing elements
        const elementsInRange = getElementsInRange(range);
        elementsInRange.forEach(el => {
          el.style.fontSize = `${value}px`;
        });
      }
      
      // Update document content
      const editor = document.getElementById('documentEditor');
      if (editor && state.currentDocument) {
        dispatch({ 
          type: 'ADD_TO_UNDO_STACK', 
          payload: state.currentDocument.content 
        });
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }
    } else {
      // If no selection, apply to the editor as default
      const editor = document.getElementById('documentEditor');
      if (editor) {
        const activeElement = document.activeElement;
        if (activeElement && editor.contains(activeElement)) {
          // Apply to the active element if it's inside the editor
          activeElement.style.fontSize = `${value}px`;
        } else {
          // Apply as default style for the editor
          editor.style.fontSize = `${value}px`;
        }
        
        if (state.currentDocument) {
          dispatch({ 
            type: 'ADD_TO_UNDO_STACK', 
            payload: state.currentDocument.content 
          });
          dispatch({ 
            type: 'UPDATE_DOCUMENT_CONTENT', 
            payload: editor.innerHTML 
          });
        }
      }
    }
  };
  
  // Helper function to get all elements in a selection range
  const getElementsInRange = (range: Range): Element[] => {
    let elements: Element[] = [];
    const startContainer = range.startContainer;
    const endContainer = range.endContainer;
    
    // If we're in the same container
    if (startContainer === endContainer) {
      if (startContainer.nodeType === Node.ELEMENT_NODE) {
        elements.push(startContainer as Element);
      } else if (startContainer.parentElement) {
        elements.push(startContainer.parentElement);
      }
      return elements;
    }
    
    // Otherwise, walk the DOM tree to find all elements in range
    const walker = document.createTreeWalker(
      document.getElementById('documentEditor') as Node,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: (node) => {
          if (range.intersectsNode(node)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_SKIP;
        }
      }
    );
    
    let currentNode = walker.currentNode;
    while (currentNode) {
      elements.push(currentNode as Element);
      currentNode = walker.nextNode() as Element;
    }
    
    return elements;
  };

  // Handle text formatting
  const handleTextFormat = (command: 'bold' | 'italic' | 'underline', range?: Range) => {
    switch (command) {
      case 'bold':
        dispatch({ type: 'TOGGLE_BOLD' });
        document.execCommand('bold', false);
        break;
      case 'italic':
        dispatch({ type: 'TOGGLE_ITALIC' });
        document.execCommand('italic', false);
        break;
      case 'underline':
        dispatch({ type: 'TOGGLE_UNDERLINE' });
        document.execCommand('underline', false);
        break;
    }
    
    // Update document content
    const editor = document.getElementById('documentEditor');
    if (editor && state.currentDocument) {
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
    }
  };
  
  // Handle checkbox insertion
  const handleInsertCheckbox = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    // Create checkbox container with draggable feature
    const container = document.createElement('div');
    container.className = 'checkbox-container';
    container.style.margin = '10px 0';
    container.style.display = 'flex';
    container.style.alignItems = 'center';
    container.style.position = 'relative';
    container.style.cursor = 'move';
    container.style.padding = '5px';
    container.style.border = '1px dashed transparent';
    container.style.borderRadius = '4px';
    container.style.zIndex = '10';
    
    // Create checkbox
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'print-control-checkbox';
    checkbox.style.marginLeft = '8px';
    
    // Add label for the checkbox
    const label = document.createElement('span');
    label.textContent = 'محتوى للطباعة';
    label.style.marginLeft = '8px';
    
    // Add a control for excluding from print
    const printControl = document.createElement('div');
    printControl.className = 'print-control';
    printControl.style.marginRight = '8px';
    printControl.style.fontSize = '12px';
    printControl.style.color = '#666';
    printControl.textContent = '(عند التحديد لا يتم طباعة المحتوى)';
    
    // Add elements to container
    container.appendChild(checkbox);
    container.appendChild(label);
    container.appendChild(printControl);
    
    // Make the container draggable
    container.addEventListener('mousedown', (startEvent) => {
      if (startEvent.target === checkbox) return; // Don't drag when clicking the checkbox
      
      startEvent.preventDefault();
      
      const initialX = startEvent.clientX;
      const initialY = startEvent.clientY;
      const initialLeft = container.offsetLeft;
      const initialTop = container.offsetTop;
      
      // Add drag effect
      container.style.border = '1px dashed #ccc';
      
      const handleMouseMove = (moveEvent: MouseEvent) => {
        const dx = moveEvent.clientX - initialX;
        const dy = moveEvent.clientY - initialY;
        
        container.style.position = 'absolute';
        container.style.left = `${initialLeft + dx}px`;
        container.style.top = `${initialTop + dy}px`;
      };
      
      const handleMouseUp = () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        
        // Remove drag effect
        container.style.border = '1px dashed transparent';
        
        // Update document content after moving
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      };
      
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    });
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert the checkbox container
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(container);
    } else {
      editor.appendChild(container);
    }
    
    // Add style for print control
    const style = document.createElement('style');
    style.textContent = `
      @media print {
        .print-control {
          display: none;
        }
        .checkbox-container {
          position: static !important;
          border: none !important;
        }
        .print-control-checkbox:checked ~ * {
          display: none !important;
        }
        .print-control-checkbox:checked {
          display: none !important;
        }
      }
    `;
    document.head.appendChild(style);
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
    
    toast({
      title: 'تم إدراج مربع اختيار',
      description: 'يمكنك استخدامه للتحكم في محتوى الطباعة والنقل إلى المكان المناسب.',
    });
  };
  
  // Handle text box insertion
  const handleInsertTextBox = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    // Create container for text box that supports resizing
    const container = document.createElement('div');
    container.className = 'text-box-container';
    container.style.position = 'relative';
    container.style.margin = '10px 0';
    container.style.minWidth = '200px';
    container.style.width = '100%';
    container.style.maxWidth = '100%';
    container.style.zIndex = '1'; // Ensure it's visible over the page
    
    // Create text box div
    const textBox = document.createElement('div');
    textBox.contentEditable = 'true';
    textBox.className = 'text-box';
    textBox.style.border = '1px solid #ccc';
    textBox.style.padding = '10px';
    textBox.style.borderRadius = '4px';
    textBox.style.minHeight = '100px';
    textBox.style.height = '100%';
    textBox.style.width = '100%';
    textBox.style.backgroundColor = '#f9f9f9';
    textBox.style.position = 'relative';
    textBox.style.zIndex = '2'; // Make sure it stays on top
    textBox.dir = state.textDirection;
    textBox.dataset.type = 'text-box';
    textBox.textContent = 'أدخل النص هنا...';
    
    // Add resize handles
    const resizeHandles = ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'right', 'left', 'top', 'bottom'];
    
    resizeHandles.forEach(position => {
      const handle = document.createElement('div');
      handle.className = `resize-handle resize-handle-${position}`;
      handle.style.position = 'absolute';
      handle.style.width = '10px';
      handle.style.height = '10px';
      handle.style.backgroundColor = '#4299e1';
      handle.style.zIndex = '1000';
      
      // Position the handle based on its type
      switch (position) {
        case 'top-left':
          handle.style.top = '-5px';
          handle.style.left = '-5px';
          handle.style.cursor = 'nwse-resize';
          break;
        case 'top-right':
          handle.style.top = '-5px';
          handle.style.right = '-5px';
          handle.style.cursor = 'nesw-resize';
          break;
        case 'bottom-left':
          handle.style.bottom = '-5px';
          handle.style.left = '-5px';
          handle.style.cursor = 'nesw-resize';
          break;
        case 'bottom-right':
          handle.style.bottom = '-5px';
          handle.style.right = '-5px';
          handle.style.cursor = 'nwse-resize';
          break;
        case 'right':
          handle.style.top = '50%';
          handle.style.right = '-5px';
          handle.style.transform = 'translateY(-50%)';
          handle.style.cursor = 'ew-resize';
          break;
        case 'left':
          handle.style.top = '50%';
          handle.style.left = '-5px';
          handle.style.transform = 'translateY(-50%)';
          handle.style.cursor = 'ew-resize';
          break;
        case 'top':
          handle.style.top = '-5px';
          handle.style.left = '50%';
          handle.style.transform = 'translateX(-50%)';
          handle.style.cursor = 'ns-resize';
          break;
        case 'bottom':
          handle.style.bottom = '-5px';
          handle.style.left = '50%';
          handle.style.transform = 'translateX(-50%)';
          handle.style.cursor = 'ns-resize';
          break;
      }
      
      // Add resize event listeners
      handle.addEventListener('mousedown', (startEvent) => {
        startEvent.preventDefault();
        startEvent.stopPropagation();
        
        // Get initial sizes
        const initialWidth = container.offsetWidth;
        const initialHeight = container.offsetHeight;
        const initialX = startEvent.clientX;
        const initialY = startEvent.clientY;
        
        // Get initial positions for moving
        const initialLeft = container.offsetLeft;
        const initialTop = container.offsetTop;
        
        const handleMouseMove = (moveEvent) => {
          moveEvent.preventDefault();
          
          // Calculate movement deltas
          const dx = moveEvent.clientX - initialX;
          const dy = moveEvent.clientY - initialY;
          
          // Apply size changes based on handle type
          switch (position) {
            case 'top-left':
              container.style.width = `${initialWidth - dx}px`;
              container.style.height = `${initialHeight - dy}px`;
              break;
            case 'top-right':
              container.style.width = `${initialWidth + dx}px`;
              container.style.height = `${initialHeight - dy}px`;
              break;
            case 'bottom-left':
              container.style.width = `${initialWidth - dx}px`;
              container.style.height = `${initialHeight + dy}px`;
              break;
            case 'bottom-right':
              container.style.width = `${initialWidth + dx}px`;
              container.style.height = `${initialHeight + dy}px`;
              break;
            case 'right':
              container.style.width = `${initialWidth + dx}px`;
              break;
            case 'left':
              container.style.width = `${initialWidth - dx}px`;
              break;
            case 'top':
              container.style.height = `${initialHeight - dy}px`;
              break;
            case 'bottom':
              container.style.height = `${initialHeight + dy}px`;
              break;
          }
        };
        
        const handleMouseUp = () => {
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
          
          // Update document content after resize
          dispatch({ 
            type: 'UPDATE_DOCUMENT_CONTENT', 
            payload: editor.innerHTML 
          });
        };
        
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
      });
      
      container.appendChild(handle);
    });
    
    container.appendChild(textBox);
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert the text box container
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(container);
      
      // Focus on the new text box
      textBox.focus();
    } else {
      editor.appendChild(container);
    }
    
    // Add custom styles for the text box
    const style = document.createElement('style');
    style.textContent = `
      .text-box-container:hover .resize-handle {
        display: block;
      }
      .resize-handle {
        display: none;
        border-radius: 50%;
      }
      .text-box:focus {
        outline: none;
        border-color: #4299e1;
        box-shadow: 0 0 0 2px rgba(66, 153, 225, 0.5);
      }
    `;
    document.head.appendChild(style);
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
  };
  
  // Handle text alignment
  const handleTextAlign = (alignment: 'right' | 'center' | 'left' | 'justify') => {
    document.execCommand('justify' + alignment, false);
    
    // Get current selection
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const selectedNodes = getNodesInRange(range);
      
      selectedNodes.forEach(node => {
        // Apply alignment to the paragraph or other block element
        let blockElement = node;
        while (blockElement && !isBlockElement(blockElement)) {
          blockElement = blockElement.parentElement as HTMLElement;
        }
        
        if (blockElement) {
          blockElement.style.textAlign = alignment;
        }
      });
    } else {
      // If no selection, apply to active element or at cursor position
      const editor = document.getElementById('documentEditor');
      if (editor) {
        const activeElement = document.activeElement;
        if (activeElement && editor.contains(activeElement) && isBlockElement(activeElement as HTMLElement)) {
          (activeElement as HTMLElement).style.textAlign = alignment;
        } else {
          // Create paragraph at cursor if none exists
          const p = document.createElement('p');
          p.style.textAlign = alignment;
          
          // Insert paragraph at cursor position
          insertAtCursor(p);
        }
      }
    }
    
    // Update document content
    const editor = document.getElementById('documentEditor');
    if (editor && state.currentDocument) {
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
    }
  };
  
  // Helper function to check if element is a block element
  const isBlockElement = (element: HTMLElement | Node) => {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }
    
    const el = element as HTMLElement;
    
    try {
      const display = window.getComputedStyle(el).display;
      return display === 'block' || display === 'flex' || display === 'grid' || 
             el.tagName === 'P' || el.tagName === 'DIV' || 
             el.tagName === 'H1' || el.tagName === 'H2' || 
             el.tagName === 'H3' || el.tagName === 'H4' || 
             el.tagName === 'H5' || el.tagName === 'H6';
    } catch (error) {
      // Fallback for when getComputedStyle fails
      return el.tagName === 'P' || el.tagName === 'DIV' || 
             el.tagName === 'H1' || el.tagName === 'H2' || 
             el.tagName === 'H3' || el.tagName === 'H4' || 
             el.tagName === 'H5' || el.tagName === 'H6';
    }
  };
  
  // Helper function to get all nodes in a selection range
  const getNodesInRange = (range: Range): Node[] => {
    let nodes: Node[] = [];
    const startContainer = range.startContainer;
    const endContainer = range.endContainer;
    
    // If we're in the same container
    if (startContainer === endContainer) {
      // If it's a text node, get its parent element
      if (startContainer.nodeType === Node.TEXT_NODE && startContainer.parentElement) {
        nodes.push(startContainer.parentElement);
      } else {
        nodes.push(startContainer);
      }
      return nodes;
    }
    
    try {
      // Walk the DOM tree to find all nodes in range
      const nodeIterator = document.createNodeIterator(
        document.getElementById('documentEditor') as Node,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
        {
          acceptNode: (node) => {
            try {
              if (range.intersectsNode(node)) {
                return NodeFilter.FILTER_ACCEPT;
              }
            } catch (e) {
              console.error('Error in acceptNode:', e);
            }
            return NodeFilter.FILTER_SKIP;
          }
        }
      );
      
      let currentNode;
      while ((currentNode = nodeIterator.nextNode())) {
        // For text nodes, add their parent elements
        if (currentNode.nodeType === Node.TEXT_NODE && currentNode.parentElement) {
          // Only add parent if not already in the array
          if (!nodes.includes(currentNode.parentElement)) {
            nodes.push(currentNode.parentElement);
          }
        } else if (currentNode.nodeType === Node.ELEMENT_NODE) {
          nodes.push(currentNode);
        }
      }
    } catch (e) {
      console.error('Error getting nodes in range:', e);
      
      // Fallback: try to get some common ancestor
      const commonAncestor = range.commonAncestorContainer;
      if (commonAncestor && commonAncestor.nodeType === Node.ELEMENT_NODE) {
        nodes.push(commonAncestor);
      } else if (commonAncestor && commonAncestor.parentElement) {
        nodes.push(commonAncestor.parentElement);
      }
    }
    
    return nodes;
  };
  
  // Helper function to insert element at cursor position
  const insertAtCursor = (element: HTMLElement) => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(element);
      
      // Move cursor inside the new element
      range.selectNodeContents(element);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
    } else {
      // If no selection, append to editor
      const editor = document.getElementById('documentEditor');
      if (editor) {
        editor.appendChild(element);
      }
    }
  };

  // Handle undo/redo
  const handleUndo = () => {
    document.execCommand('undo', false);
    if (state.undoStack.length > 0) {
      dispatch({ type: 'UNDO' });
    }
  };

  const handleRedo = () => {
    document.execCommand('redo', false);
    if (state.redoStack.length > 0) {
      dispatch({ type: 'REDO' });
    }
  };

  // Handle import/export
  const handleImport = async () => {
    // Create a file input element
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.docx,.xlsx,.csv,.txt,.html,.htm';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      // Show loading toast
      toast({
        title: 'جاري استيراد المستند...',
        description: 'يرجى الانتظار حتى انتهاء عملية الاستيراد.',
      });
      
      // Create form data for file upload
      const formData = new FormData();
      formData.append('file', file);
      
      try {
        // First try via API
        const response = await fetch('/api/documents/import', {
          method: 'POST',
          body: formData,
          credentials: 'include'
        });
        
        if (!response.ok) {
          throw new Error('Failed to import file via API');
        }
        
        const result = await response.json();
        
        // Update the editor with the imported content
        if (result.content) {
          const editor = document.getElementById('documentEditor');
          if (editor && state.currentDocument) {
            dispatch({ 
              type: 'ADD_TO_UNDO_STACK', 
              payload: state.currentDocument.content 
            });
            
            // Parse the content and handle it properly based on its format
            let parsedContent = result.content;
            try {
              // Check if content might be JSON-encoded HTML
              if (typeof result.content === 'string' && (result.content.startsWith('{') || result.content.startsWith('['))) {
                const parsed = JSON.parse(result.content);
                if (parsed.html) {
                  parsedContent = parsed.html;
                } else if (parsed.content) {
                  parsedContent = parsed.content;
                }
              }
            } catch (e) {
              console.log('Content is not JSON, using as is');
            }
            
            // Create a temporary div to sanitize the content
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = parsedContent;
            
            // Set the content in the editor element directly
            editor.innerHTML = tempDiv.innerHTML;
            
            // Update document title if available
            if (result.title) {
              dispatch({
                type: 'SET_DOCUMENT',
                payload: {
                  ...state.currentDocument,
                  title: result.title,
                  content: tempDiv.innerHTML
                }
              });
            }
            
            // Then update the state after a short delay to ensure rendering
            setTimeout(() => {
              dispatch({ 
                type: 'UPDATE_DOCUMENT_CONTENT', 
                payload: editor.innerHTML 
              });
              
              toast({
                title: 'تم استيراد المستند',
                description: 'تم استيراد المستند بنجاح.',
              });
            }, 100);
          }
        }
      } catch (error) {
        console.error('Import error:', error);
        
        // Fallback approach: read the file directly if API fails
        try {
          const reader = new FileReader();
          
          reader.onload = (event) => {
            if (!event.target?.result) return;
            
            const content = event.target.result as string;
            const editor = document.getElementById('documentEditor');
            
            if (editor && state.currentDocument) {
              dispatch({ 
                type: 'ADD_TO_UNDO_STACK', 
                payload: state.currentDocument.content 
              });
              
              // Create a temporary div to parse HTML files properly
              const tempDiv = document.createElement('div');
              
              // Handle different file types
              if (file.name.endsWith('.html') || file.name.endsWith('.htm')) {
                tempDiv.innerHTML = content;
              } else if (file.name.endsWith('.txt')) {
                // For text files, convert newlines to <br> tags
                tempDiv.innerHTML = content.replace(/\n/g, '<br>');
              } else {
                // For other file types, just use the text content
                tempDiv.textContent = content;
              }
              
              // Apply basic sanitization (if needed, add more sophisticated sanitization here)
              const sanitizedContent = tempDiv.innerHTML;
              
              // Update the editor with the imported content
              editor.innerHTML = sanitizedContent;
              
              // Update the document state
              dispatch({
                type: 'SET_DOCUMENT',
                payload: {
                  ...state.currentDocument,
                  title: file.name.split('.')[0],
                  content: sanitizedContent
                }
              });
              
              // Then update the content state
              dispatch({ 
                type: 'UPDATE_DOCUMENT_CONTENT', 
                payload: editor.innerHTML 
              });
              
              toast({
                title: 'تم استيراد المستند',
                description: 'تم استيراد المستند بطريقة بديلة.',
              });
            }
          };
          
          // Read the file as text
          if (file.name.endsWith('.html') || file.name.endsWith('.htm') || file.name.endsWith('.txt')) {
            reader.readAsText(file);
          } else {
            // For other file types try as binary/text
            reader.readAsText(file);
          }
          
        } catch (fallbackError) {
          console.error('Fallback import error:', fallbackError);
          toast({
            title: 'فشل استيراد المستند',
            description: 'فشلت عملية استيراد المستند. يرجى المحاولة مرة أخرى باستخدام ملف بتنسيق مختلف.',
            variant: 'destructive'
          });
        }
      }
    };
    
    input.click();
  };

  const handleExport = async (format: 'word' | 'excel' | 'pdf') => {
    // Get the current editor content
    const editor = document.getElementById('documentEditor');
    if (!editor) {
      toast({
        title: 'محتوى فارغ',
        description: 'لا يوجد محتوى للتصدير',
        variant: 'destructive'
      });
      return;
    }
    
    try {
      // Get document title - use saved title or default
      const documentTitle = state.currentDocument?.title || 'مستند جديد';
      
      // For saved documents, use the normal export endpoint
      if (state.currentDocument?.id) {
        const response = await apiRequest(
          'GET', 
          `/api/documents/${state.currentDocument.id}/export?format=${format}`,
          undefined
        );
        
        // Get blob from response
        const blob = await response.blob();
        
        // Create download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${documentTitle}.${format}`;
        document.body.appendChild(a);
        a.click();
        
        // Clean up
        window.URL.revokeObjectURL(url);
        setTimeout(() => document.body.removeChild(a), 100);
        return;
      }
      
      // For unsaved documents, use the temp export endpoint
      const content = editor.innerHTML;
      const response = await apiRequest(
        'POST', 
        `/api/documents/temp/export?format=${format}`, 
        { title: documentTitle, content }
      );
      
      // Get blob from response
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${documentTitle}.${format}`;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: 'Export successful',
        description: `The document has been exported as ${format.toUpperCase()}.`
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: 'Export failed',
        description: 'Failed to export the document. Please try again.',
        variant: 'destructive'
      });
    }
  };

  // Handle print
  const handlePrint = () => {
    window.print();
  };

  // Handle image insertion
  const handleInsertImage = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      // Create form data for file upload
      const formData = new FormData();
      formData.append('image', file);
      
      try {
        // Show loading toast
        toast({
          title: 'جاري تحميل الصورة...',
          description: 'الرجاء الانتظار...',
        });
        
        // Instead of using the API, directly create a placeholder URL
        // Until we implement actual server-side image handling
        const imageUrl = URL.createObjectURL(file);
        
        // Insert the image into the editor
        const editor = document.getElementById('documentEditor');
        if (editor && state.currentDocument) {
          // Create image wrapper for better handling
          const imgContainer = document.createElement('div');
          imgContainer.className = 'image-container';
          imgContainer.dataset.type = 'image-container';
          imgContainer.style.position = 'relative';
          imgContainer.style.margin = '10px 0';
          imgContainer.style.display = 'inline-block';
          imgContainer.style.maxWidth = '100%';
          
          // Create image element
          const img = document.createElement('img');
          img.src = imageUrl;
          img.alt = file.name;
          img.style.maxWidth = '100%';
          img.className = 'document-image';
          
          // Add the image to container
          imgContainer.appendChild(img);
          
          // Save current content to undo stack
          dispatch({ 
            type: 'ADD_TO_UNDO_STACK', 
            payload: state.currentDocument.content 
          });
          
          // Insert the image container
          const selection = window.getSelection();
          if (selection && selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            range.deleteContents();
            range.insertNode(imgContainer);
          } else {
            editor.appendChild(imgContainer);
          }
          
          // Update document content
          dispatch({ 
            type: 'UPDATE_DOCUMENT_CONTENT', 
            payload: editor.innerHTML 
          });
          
          // Show success message
          toast({
            title: 'تم إدراج الصورة',
            description: 'تم إدراج الصورة بنجاح في المستند.',
          });
        }
      } catch (error) {
        console.error('Image insertion error:', error);
        toast({
          title: 'فشل إدراج الصورة',
          description: 'حدث خطأ أثناء إدراج الصورة. الرجاء المحاولة مرة أخرى.',
          variant: 'destructive'
        });
      }
    };
    
    input.click();
  };

  // JSX for toolbar
  return (
    <div className="w-full md:w-64 bg-white dark:bg-gray-900 rounded-lg shadow-md p-4 mb-6 md:mb-0 md:ml-6">
      <h2 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">أدوات التحرير</h2>
      
      <div className="space-y-4">
        {/* Text Insertion */}
        <div className="border-b pb-4 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">إدراج نص</h3>
          <Button
            variant="outline"
            className="w-full flex items-center justify-center"
            onClick={handleInsertText}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <path d="M17 7H7v2h10V7z"/>
              <path d="M13 17H7v-2h6v2z"/>
              <path d="M3 5v14h18V5H3z"/>
            </svg>
            إضافة نص
          </Button>
        </div>
        
        {/* Text Direction */}
        <div className="border-b pb-4 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">اتجاه النص</h3>
          <div className="flex space-x-2 space-x-reverse">
            <Button
              variant="outline"
              className="flex-1 flex items-center justify-center"
              onClick={() => handleTextDirection('rtl')}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M8 10h12"/>
                <path d="M8 14h12"/>
                <path d="M4 10l-2 2 2 2V10z"/>
                <path d="M4 6v12"/>
              </svg>
            </Button>
            <Button
              variant="outline"
              className="flex-1 flex items-center justify-center"
              onClick={() => handleTextDirection('ltr')}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M4 10h12"/>
                <path d="M4 14h12"/>
                <path d="M20 10l2 2-2 2V10z"/>
                <path d="M20 6v12"/>
              </svg>
            </Button>
          </div>
        </div>
        
        {/* Font Settings */}
        <div className="border-b pb-4 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">إعدادات الخط</h3>
          
          <div className="mb-2">
            <Select
              value={state.fontFamily}
              onValueChange={handleFontFamilyChange}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="اختر الخط" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="times-new-roman">Times New Roman</SelectItem>
                <SelectItem value="amiri">Amiri</SelectItem>
                <SelectItem value="arial">Arial</SelectItem>
                <SelectItem value="courier">Courier New</SelectItem>
                <SelectItem value="tahoma">Tahoma</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            <Select
              value={state.fontSize}
              onValueChange={handleFontSizeChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="حجم الخط" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10px</SelectItem>
                <SelectItem value="12">12px</SelectItem>
                <SelectItem value="14">14px</SelectItem>
                <SelectItem value="16">16px</SelectItem>
                <SelectItem value="18">18px</SelectItem>
                <SelectItem value="20">20px</SelectItem>
                <SelectItem value="24">24px</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex space-x-1 space-x-reverse">
              <Button
                variant={state.isBold ? "default" : "outline"}
                className="flex-1"
                onClick={() => handleTextFormat('bold')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/>
                  <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/>
                </svg>
              </Button>
              <Button
                variant={state.isItalic ? "default" : "outline"}
                className="flex-1"
                onClick={() => handleTextFormat('italic')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <line x1="19" y1="4" x2="10" y2="4"/>
                  <line x1="14" y1="20" x2="5" y2="20"/>
                  <line x1="15" y1="4" x2="9" y2="20"/>
                </svg>
              </Button>
              <Button
                variant={state.isUnderline ? "default" : "outline"}
                className="flex-1"
                onClick={() => handleTextFormat('underline')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M6 3v7a6 6 0 0 0 6 6 6 6 0 0 0 6-6V3"/>
                  <line x1="4" y1="21" x2="20" y2="21"/>
                </svg>
              </Button>
            </div>

            <div className="mt-2 grid grid-cols-3 gap-1">
              <Button
                variant="outline"
                className="flex items-center justify-center"
                onClick={() => handleTextAlign('right')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <line x1="21" y1="6" x2="3" y2="6"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                  <line x1="21" y1="18" x2="7" y2="18"/>
                </svg>
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center"
                onClick={() => handleTextAlign('center')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <line x1="18" y1="6" x2="6" y2="6"/>
                  <line x1="21" y1="12" x2="3" y2="12"/>
                  <line x1="18" y1="18" x2="6" y2="18"/>
                </svg>
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center"
                onClick={() => handleTextAlign('left')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <line x1="3" y1="6" x2="21" y2="6"/>
                  <line x1="3" y1="12" x2="15" y2="12"/>
                  <line x1="3" y1="18" x2="17" y2="18"/>
                </svg>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Table Insertion */}
        <div className="border-b pb-4 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">إضافة جدول</h3>
          <Button
            variant="outline"
            className="w-full flex items-center justify-center"
            onClick={handleDirectTableInsertion}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <line x1="3" y1="9" x2="21" y2="9"/>
              <line x1="3" y1="15" x2="21" y2="15"/>
              <line x1="9" y1="3" x2="9" y2="21"/>
              <line x1="15" y1="3" x2="15" y2="21"/>
            </svg>
            إدراج جدول
          </Button>
        </div>
        
        {/* Images and Media */}
        <div className="border-b pb-4 dark:border-gray-700">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">وسائط</h3>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleInsertImage}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-1" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
              </svg>
              صورة
            </Button>
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={() => setShowLocationModal(true)}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-1" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
              موقع
            </Button>
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleInsertTextBox}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-1" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                <line x1="3" y1="9" x2="21" y2="9"/>
                <line x1="9" y1="21" x2="9" y2="9"/>
              </svg>
              مربع نص
            </Button>
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleInsertCheckbox}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-1" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <polyline points="9 11 12 14 22 4"></polyline>
                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
              </svg>
              مربع اختيار
            </Button>
          </div>
        </div>
        
        {/* Document Actions */}
        <div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">إجراءات المستند</h3>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleUndo}
              disabled={state.undoStack.length === 0}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M3 7v6h6"/>
                <path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/>
              </svg>
            </Button>
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleRedo}
              disabled={state.redoStack.length === 0}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M21 7v6h-6"/>
                <path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13"/>
              </svg>
            </Button>
          </div>
          
          <div className="mt-4 space-y-2">
            <Button
              variant="outline"
              className="w-full flex items-center justify-center"
              onClick={handleImport}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="17 8 12 3 7 8"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
              استيراد
            </Button>
            
            <div className="flex space-x-2 space-x-reverse">
              <Button
                variant="outline"
                className="flex-1 text-xs flex items-center justify-center"
                onClick={() => handleExport('word')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-1" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                  <polyline points="10 9 9 9 8 9"/>
                </svg>
                Word
              </Button>
              <Button
                variant="outline"
                className="flex-1 text-xs flex items-center justify-center"
                onClick={() => handleExport('excel')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-1" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                  <line x1="3" y1="9" x2="21" y2="9"/>
                  <line x1="3" y1="15" x2="21" y2="15"/>
                  <line x1="9" y1="3" x2="9" y2="21"/>
                  <line x1="15" y1="3" x2="15" y2="21"/>
                </svg>
                Excel
              </Button>
              <Button
                variant="outline"
                className="flex-1 text-xs flex items-center justify-center"
                onClick={() => handleExport('pdf')}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-1" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                  <polyline points="10 9 9 9 8 9"/>
                </svg>
                PDF
              </Button>
            </div>
            
            <Button
              variant="outline"
              className="w-full flex items-center justify-center"
              onClick={handlePrint}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <polyline points="6 9 6 2 18 2 18 9"/>
                <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>
                <rect x="6" y="14" width="12" height="8"/>
              </svg>
              طباعة
            </Button>
          </div>
        </div>
      </div>
      
      {/* Modals */}
      {showTableModal && (
        <TableModal 
          isOpen={showTableModal} 
          onClose={() => setShowTableModal(false)} 
        />
      )}
      
      {showDropdownModal && (
        <DropdownModal 
          isOpen={showDropdownModal} 
          onClose={() => setShowDropdownModal(false)} 
        />
      )}
      
      {showLocationModal && (
        <LocationModal 
          isOpen={showLocationModal} 
          onClose={() => setShowLocationModal(false)} 
        />
      )}
    </div>
  );
}
