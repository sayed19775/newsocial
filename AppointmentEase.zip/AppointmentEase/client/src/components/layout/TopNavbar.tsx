import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useDocument } from '@/contexts/DocumentContext';
import { useTheme } from '@/hooks/useTheme';
import { 
  Save, Menu, FileDown, FilePlus, User, 
  LogOut, Moon, Sun, Settings 
} from 'lucide-react';

interface TopNavbarProps {
  onSave?: () => void;
  isSaving?: boolean;
}

export default function TopNavbar({ onSave, isSaving = false }: TopNavbarProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const { documentState } = useDocument();
  const { toggleTheme } = useTheme();
  
  const handleToggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
    // Dispatch an event for the Sidebar component to listen to
    window.dispatchEvent(new CustomEvent('toggle-sidebar'));
  };
  
  return (
    <nav className="bg-white dark:bg-gray-800 shadow px-4 py-2 flex items-center justify-between no-print">
      <div className="flex items-center">
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden"
          onClick={handleToggleSidebar}
        >
          <Menu className="h-5 w-5" />
        </Button>
        
        <Link href="/" className="flex items-center mx-4">
          <span className="material-icons">description</span>
          <h1 className="mr-2 text-xl font-medium">محرر المستندات A4</h1>
        </Link>
        
        <div className="hidden md:flex items-center space-x-2 rtl:space-x-reverse">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center"
            onClick={onSave}
            disabled={isSaving}
          >
            <Save className="h-4 w-4 ml-2" />
            {isSaving ? 'جاري الحفظ...' : 'حفظ'}
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <FileDown className="h-4 w-4 ml-2" />
                تصدير
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <span>تصدير إلى PDF</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <span>تصدير إلى Word</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <span>تصدير إلى Excel</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button variant="outline" size="sm" className="flex items-center">
            <FilePlus className="h-4 w-4 ml-2" />
            حفظ كقالب
          </Button>
        </div>
      </div>
      
      <div className="flex items-center space-x-4 rtl:space-x-reverse">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleTheme}
          className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
        >
          <Moon className="h-5 w-5 dark:hidden" />
          <Sun className="h-5 w-5 hidden dark:block" />
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <User className="h-6 w-6" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>حسابي</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="ml-2 h-4 w-4" />
              <span>الملف الشخصي</span>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Settings className="ml-2 h-4 w-4" />
              <span>الإعدادات</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <LogOut className="ml-2 h-4 w-4" />
              <span>تسجيل الخروج</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <div className="text-sm font-medium text-gray-900 dark:text-gray-100 hidden md:block">
          {documentState.title}
        </div>
      </div>
    </nav>
  );
}
