import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Separator, 
  ScrollArea, 
  Tabs, 
  TabsList, 
  TabsTrigger, 
  TabsContent 
} from '@/components/ui/components';
import { useDocument } from '@/contexts/DocumentContext';
import { 
  Type, Bold, RotateCcw, AlignRight, AlignLeft, 
  Table, Rows, Columns, ChevronDown, Undo, Redo, 
  Upload, Download, Printer, Image, MapPin, CheckSquare, 
  FileText, Layout, Square
} from 'lucide-react';

interface SidebarProps {
  onInsertTable?: () => void;
  onInsertLocation?: () => void;
}

export default function Sidebar({ onInsertTable, onInsertLocation }: SidebarProps) {
  const [isVisible, setIsVisible] = useState(true);
  const { 
    documentState, 
    addTextBlock, 
    undo, redo, 
    canUndo, canRedo, 
    addCheckboxBlock,
    addImageBlock,
  } = useDocument();

  // Listen for sidebar toggle events from the TopNavbar component
  useEffect(() => {
    const handleToggleSidebar = () => {
      setIsVisible((prev) => !prev);
    };
    
    window.addEventListener('toggle-sidebar', handleToggleSidebar);
    
    // Handle responsive design for smaller screens
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => {
      window.removeEventListener('toggle-sidebar', handleToggleSidebar);
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Handle text insertion
  const handleInsertText = () => {
    addTextBlock('', 'rtl');
  };
  
  // Handle font family change
  const handleFontFamilyChange = (value: string) => {
    // Update selected text block with new font family
  };
  
  // Handle font size change
  const handleFontSizeChange = (value: string) => {
    // Update selected text block with new font size
  };
  
  // Handle checkbox insertion
  const handleInsertCheckbox = () => {
    addCheckboxBlock('خيار جديد');
  };
  
  // Handle image insertion
  const handleInsertImage = () => {
    // Open a file input dialog
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: Event) => {
      const target = e.target as HTMLInputElement;
      if (target.files && target.files.length > 0) {
        const file = target.files[0];
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            addImageBlock(reader.result);
          }
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };
  
  // Handle print document
  const handlePrint = () => {
    window.print();
  };
  
  if (!isVisible) {
    return null;
  }
  
  return (
    <aside className="w-64 bg-white dark:bg-gray-800 shadow-md flex flex-col no-print" id="sidebar">
      <ScrollArea className="flex-1">
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-4">أدوات التحرير</h2>
          
          <Tabs defaultValue="text">
            <TabsList className="mb-4 w-full grid grid-cols-3 h-9">
              <TabsTrigger value="text" className="text-xs">النص</TabsTrigger>
              <TabsTrigger value="table" className="text-xs">الجداول</TabsTrigger>
              <TabsTrigger value="document" className="text-xs">المستند</TabsTrigger>
            </TabsList>
            
            <TabsContent value="text" className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium text-sm text-gray-600 dark:text-gray-300 uppercase">إضافة نص</h3>
                <div className="flex flex-wrap gap-2">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8" 
                    title="إدراج نص"
                    onClick={handleInsertText}
                  >
                    <Type className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="غامق">
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="اتجاه النص من اليمين إلى اليسار">
                    <AlignRight className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="اتجاه النص من اليسار إلى اليمين">
                    <AlignLeft className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="flex flex-col gap-2 mt-2">
                  <label className="text-sm">الخط:</label>
                  <Select onValueChange={handleFontFamilyChange} defaultValue="times">
                    <SelectTrigger className="h-8">
                      <SelectValue placeholder="اختر الخط" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="times">Times New Roman</SelectItem>
                      <SelectItem value="arial">Arial</SelectItem>
                      <SelectItem value="calibri">Calibri</SelectItem>
                      <SelectItem value="tahoma">Tahoma</SelectItem>
                      <SelectItem value="courier">Courier New</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex flex-col gap-2">
                  <label className="text-sm">الحجم:</label>
                  <Select onValueChange={handleFontSizeChange} defaultValue="14">
                    <SelectTrigger className="h-8">
                      <SelectValue placeholder="اختر الحجم" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="12">12</SelectItem>
                      <SelectItem value="14">14</SelectItem>
                      <SelectItem value="16">16</SelectItem>
                      <SelectItem value="18">18</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="24">24</SelectItem>
                      <SelectItem value="28">28</SelectItem>
                      <SelectItem value="32">32</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="table" className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium text-sm text-gray-600 dark:text-gray-300 uppercase">الجداول</h3>
                <div className="flex flex-wrap gap-2">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8" 
                    title="إدراج جدول"
                    onClick={onInsertTable}
                  >
                    <Table className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="دمج الخلايا">
                    <Rows className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="تقسيم الخلايا">
                    <Columns className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-8 w-8" title="إدراج قائمة منسدلة">
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">إرشادات الجداول:</h4>
                  <ul className="text-xs text-gray-600 dark:text-gray-300 space-y-1 list-disc list-inside">
                    <li>انقر على زر الجدول لإنشاء جدول جديد</li>
                    <li>يمكنك تغيير حجم الخلايا بالسحب</li>
                    <li>دعم للصيغ الحسابية مثل SUM و AVG</li>
                    <li>يمكن دمج الخلايا المتجاورة</li>
                  </ul>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="document" className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium text-sm text-gray-600 dark:text-gray-300 uppercase">أدوات المستند</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={undo}
                    disabled={!canUndo}
                  >
                    <Undo className="ml-1 h-3 w-3" />
                    تراجع
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={redo}
                    disabled={!canRedo}
                  >
                    <Redo className="ml-1 h-3 w-3" />
                    إعادة
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 flex items-center justify-center text-xs">
                    <Upload className="ml-1 h-3 w-3" />
                    استيراد
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 flex items-center justify-center text-xs">
                    <Download className="ml-1 h-3 w-3" />
                    تصدير
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={handlePrint}
                  >
                    <Printer className="ml-1 h-3 w-3" />
                    طباعة
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={handleInsertImage}
                  >
                    <Image className="ml-1 h-3 w-3" />
                    صورة
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={onInsertLocation}
                  >
                    <MapPin className="ml-1 h-3 w-3" />
                    موقع
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 flex items-center justify-center text-xs"
                    onClick={handleInsertCheckbox}
                  >
                    <CheckSquare className="ml-1 h-3 w-3" />
                    اختيار
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <h3 className="font-medium text-sm text-gray-600 dark:text-gray-300 uppercase">القوالب</h3>
                <div className="space-y-1">
                  <Button variant="ghost" className="w-full justify-between h-8 text-xs">
                    <span className="flex items-center">
                      <FileText className="ml-2 h-3 w-3" />
                      قالب محاسبي
                    </span>
                  </Button>
                  <Button variant="ghost" className="w-full justify-between h-8 text-xs">
                    <span className="flex items-center">
                      <FileText className="ml-2 h-3 w-3" />
                      نموذج طلب
                    </span>
                  </Button>
                  <Button variant="ghost" className="w-full justify-between h-8 text-xs">
                    <span className="flex items-center">
                      <FileText className="ml-2 h-3 w-3" />
                      تقرير شهري
                    </span>
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </ScrollArea>
    </aside>
  );
}
