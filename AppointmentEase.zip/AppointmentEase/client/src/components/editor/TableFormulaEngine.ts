import { TableBlock } from '@shared/schema';

// Supported formula operations
type Operation = 'SUM' | 'AVERAGE' | 'COUNT' | 'MAX' | 'MIN' | 'PRODUCT';

// Cell reference in Excel-like format (e.g., A1, B2)
interface CellRef {
  col: number;
  row: number;
}

// Cell range reference (e.g., A1:C3)
interface CellRange {
  startCol: number;
  startRow: number;
  endCol: number;
  endRow: number;
}

/**
 * Evaluates a formula in the context of a table
 * @param table The table block containing the data
 * @param formula The formula to evaluate (e.g., "=SUM(A1:A5)")
 * @returns The calculated result
 */
export function evaluateFormula(table: TableBlock, formula: string): number {
  // Remove '=' if present at the beginning
  formula = formula.trim();
  if (formula.startsWith('=')) {
    formula = formula.substring(1).trim();
  }

  // Check if formula is a simple arithmetic expression
  if (!formula.includes('(') && !formula.includes(')')) {
    return evaluateArithmeticExpression(table, formula);
  }

  // Extract operation and range
  const match = formula.match(/^([A-Z]+)\((.*)\)$/);
  if (!match) {
    throw new Error(`Invalid formula format: ${formula}`);
  }

  const operation = match[1] as Operation;
  const rangeStr = match[2];

  // Process range (can be a single cell, a range, or multiple ranges)
  const ranges = rangeStr.split(',').map(r => parseRange(r.trim()));

  // Get all cell values from the ranges
  const values: number[] = [];
  
  for (const range of ranges) {
    if ('startCol' in range) {
      // It's a cell range
      const rangeVals = getCellValuesFromRange(table, range);
      values.push(...rangeVals);
    } else {
      // It's a single cell
      const value = getCellValue(table, range);
      if (!isNaN(value)) {
        values.push(value);
      }
    }
  }

  // Apply the operation to the values
  return applyOperation(operation, values);
}

/**
 * Evaluates a simple arithmetic expression like "A1+B2*C3"
 */
function evaluateArithmeticExpression(table: TableBlock, expression: string): number {
  // Replace cell references with their values
  const processedExpression = expression.replace(/[A-Z]+[0-9]+/g, (cellRef) => {
    const ref = parseCellReference(cellRef);
    const value = getCellValue(table, ref);
    return value.toString();
  });

  // Use Function constructor to safely evaluate the expression
  // This is a simple approach; in a production environment, you might want a more robust parser
  try {
    // eslint-disable-next-line no-new-func
    return Function(`"use strict"; return (${processedExpression})`)();
  } catch (error) {
    console.error('Error evaluating expression:', expression, error);
    return 0;
  }
}

/**
 * Parses a cell reference or range string
 * @param rangeStr Cell reference (e.g., "A1") or range (e.g., "A1:C3")
 * @returns Parsed cell reference or range
 */
function parseRange(rangeStr: string): CellRef | CellRange {
  if (rangeStr.includes(':')) {
    // It's a range like A1:C3
    const [start, end] = rangeStr.split(':');
    const startRef = parseCellReference(start);
    const endRef = parseCellReference(end);
    
    return {
      startCol: startRef.col,
      startRow: startRef.row,
      endCol: endRef.col,
      endRow: endRef.row,
    };
  } else {
    // It's a single cell like A1
    return parseCellReference(rangeStr);
  }
}

/**
 * Parses a cell reference in Excel format (e.g., "A1", "BC23")
 * @param cellRef Cell reference string
 * @returns Parsed column and row indices (0-based)
 */
function parseCellReference(cellRef: string): CellRef {
  const match = cellRef.match(/^([A-Z]+)([0-9]+)$/);
  if (!match) {
    throw new Error(`Invalid cell reference: ${cellRef}`);
  }

  const colStr = match[1];
  const rowStr = match[2];

  // Convert column letters to 0-based index (A=0, B=1, ..., Z=25, AA=26, ...)
  let colIndex = 0;
  for (let i = 0; i < colStr.length; i++) {
    colIndex = colIndex * 26 + (colStr.charCodeAt(i) - 'A'.charCodeAt(0) + 1);
  }
  colIndex--; // Convert to 0-based

  // Convert row number to 0-based index
  const rowIndex = parseInt(rowStr, 10) - 1;

  return { col: colIndex, row: rowIndex };
}

/**
 * Gets all cell values from a range
 */
function getCellValuesFromRange(table: TableBlock, range: CellRange): number[] {
  const values: number[] = [];

  for (let rowIdx = range.startRow; rowIdx <= range.endRow; rowIdx++) {
    if (rowIdx >= table.rows.length) continue;
    
    for (let colIdx = range.startCol; colIdx <= range.endCol; colIdx++) {
      if (colIdx >= table.rows[rowIdx].cells.length) continue;
      
      const cell = table.rows[rowIdx].cells[colIdx];
      const value = parseFloat(cell.content);
      
      if (!isNaN(value)) {
        values.push(value);
      }
    }
  }

  return values;
}

/**
 * Gets a value from a single cell
 */
function getCellValue(table: TableBlock, cellRef: CellRef): number {
  if (cellRef.row < 0 || cellRef.row >= table.rows.length) {
    return 0;
  }
  
  const row = table.rows[cellRef.row];
  
  if (cellRef.col < 0 || cellRef.col >= row.cells.length) {
    return 0;
  }
  
  const cell = row.cells[cellRef.col];
  const value = parseFloat(cell.content);
  
  return isNaN(value) ? 0 : value;
}

/**
 * Applies an operation to a set of values
 */
function applyOperation(operation: Operation, values: number[]): number {
  if (values.length === 0) {
    return 0;
  }

  switch (operation) {
    case 'SUM':
      return values.reduce((sum, value) => sum + value, 0);
    
    case 'AVERAGE':
      return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
    
    case 'COUNT':
      return values.length;
    
    case 'MAX':
      return Math.max(...values);
    
    case 'MIN':
      return Math.min(...values);
    
    case 'PRODUCT':
      return values.reduce((product, value) => product * value, 1);
    
    default:
      throw new Error(`Unsupported operation: ${operation}`);
  }
}

/**
 * Formats a number for display in a table cell
 */
export function formatNumber(value: number): string {
  // Format with up to 2 decimal places
  return Number.isInteger(value) ? value.toString() : value.toFixed(2);
}
