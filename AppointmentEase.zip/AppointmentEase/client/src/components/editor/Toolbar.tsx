import { useState } from 'react';
import { useDocument } from '@/contexts/DocumentContext';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Type,
  Bold,
  Italic,
  AlignRight,
  AlignLeft,
  Table,
  Image,
  MapPin,
  CheckSquare,
  List,
  Undo,
  Redo,
  Trash2,
  ChevronDown,
  MoveHorizontal,
  MoveVertical,
} from 'lucide-react';

interface ToolbarProps {
  onInsertTable?: () => void;
  onInsertLocation?: () => void;
  onExport?: () => void;
  onImport?: () => void;
  selectedBlockId?: string | null;
}

export default function Toolbar({
  onInsertTable,
  onInsertLocation,
  onExport,
  onImport,
  selectedBlockId,
}: ToolbarProps) {
  const {
    addTextBlock,
    undo,
    redo,
    canUndo,
    canRedo,
    addCheckboxBlock,
    addImageBlock,
    removeBlock,
    updateBlock,
    documentState,
  } = useDocument();

  const [fontFamily, setFontFamily] = useState<string>('Times New Roman');
  const [fontSize, setFontSize] = useState<string>('14');
  const [direction, setDirection] = useState<'rtl' | 'ltr'>('rtl');

  // Get the selected block from the document state
  const selectedBlock = selectedBlockId
    ? documentState.blocks.find((block) => block.id === selectedBlockId)
    : null;

  // Handle text insertion
  const handleInsertText = () => {
    addTextBlock('', direction);
  };

  // Handle checkbox insertion
  const handleInsertCheckbox = () => {
    addCheckboxBlock('خيار جديد');
  };

  // Handle image insertion
  const handleInsertImage = () => {
    // Open a file input dialog
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e: Event) => {
      const target = e.target as HTMLInputElement;
      if (target.files && target.files.length > 0) {
        const file = target.files[0];
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            addImageBlock(reader.result);
          }
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  // Handle font family change for selected block
  const handleFontFamilyChange = (value: string) => {
    setFontFamily(value);
    if (selectedBlockId && selectedBlock) {
      if (selectedBlock.type === 'text') {
        updateBlock(selectedBlockId, {
          ...selectedBlock,
          fontFamily: value,
        });
      } else if (selectedBlock.type === 'table') {
        // For table, we would need to update the selected cell
        // This would require more complex state management
      }
    }
  };

  // Handle font size change for selected block
  const handleFontSizeChange = (value: string) => {
    setFontSize(value);
    if (selectedBlockId && selectedBlock) {
      if (selectedBlock.type === 'text') {
        updateBlock(selectedBlockId, {
          ...selectedBlock,
          fontSize: parseInt(value),
        });
      }
    }
  };

  // Handle text direction change
  const handleDirectionChange = (newDirection: 'rtl' | 'ltr') => {
    setDirection(newDirection);
    if (selectedBlockId && selectedBlock) {
      if (selectedBlock.type === 'text') {
        updateBlock(selectedBlockId, {
          ...selectedBlock,
          direction: newDirection,
        });
      }
    }
  };

  // Handle bold toggle
  const handleBoldToggle = () => {
    if (selectedBlockId && selectedBlock && selectedBlock.type === 'text') {
      updateBlock(selectedBlockId, {
        ...selectedBlock,
        fontWeight: selectedBlock.fontWeight === 'bold' ? 'normal' : 'bold',
      });
    }
  };

  // Handle delete block
  const handleDeleteBlock = () => {
    if (selectedBlockId && confirm('هل أنت متأكد من رغبتك في حذف هذا العنصر؟')) {
      removeBlock(selectedBlockId);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-2 flex flex-wrap items-center gap-2">
      {/* Text controls */}
      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إدراج نص"
        onClick={handleInsertText}
      >
        <Type className="h-4 w-4" />
      </Button>

      <div className="flex items-center">
        <div className="relative">
          <Select value={fontFamily} onValueChange={handleFontFamilyChange}>
            <SelectTrigger className="h-8 w-32">
              <SelectValue placeholder="الخط" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Times New Roman">Times New Roman</SelectItem>
              <SelectItem value="Arial">Arial</SelectItem>
              <SelectItem value="Calibri">Calibri</SelectItem>
              <SelectItem value="Tahoma">Tahoma</SelectItem>
              <SelectItem value="Courier New">Courier New</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center">
        <div className="relative">
          <Select value={fontSize} onValueChange={handleFontSizeChange}>
            <SelectTrigger className="h-8 w-16">
              <SelectValue placeholder="الحجم" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="10">10</SelectItem>
              <SelectItem value="12">12</SelectItem>
              <SelectItem value="14">14</SelectItem>
              <SelectItem value="16">16</SelectItem>
              <SelectItem value="18">18</SelectItem>
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="24">24</SelectItem>
              <SelectItem value="28">28</SelectItem>
              <SelectItem value="32">32</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="h-8 border-r border-gray-300 dark:border-gray-600 mx-1"></div>

      {/* Text formatting */}
      <Button
        variant="outline"
        size="sm"
        className={`h-8 w-8 ${
          selectedBlock?.type === 'text' && selectedBlock.fontWeight === 'bold'
            ? 'bg-gray-200 dark:bg-gray-700'
            : ''
        }`}
        title="غامق"
        onClick={handleBoldToggle}
      >
        <Bold className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        className={`h-8 w-8 ${
          selectedBlock?.type === 'text' && selectedBlock.direction === 'rtl'
            ? 'bg-gray-200 dark:bg-gray-700'
            : ''
        }`}
        title="اتجاه النص من اليمين إلى اليسار"
        onClick={() => handleDirectionChange('rtl')}
      >
        <AlignRight className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        className={`h-8 w-8 ${
          selectedBlock?.type === 'text' && selectedBlock.direction === 'ltr'
            ? 'bg-gray-200 dark:bg-gray-700'
            : ''
        }`}
        title="اتجاه النص من اليسار إلى اليمين"
        onClick={() => handleDirectionChange('ltr')}
      >
        <AlignLeft className="h-4 w-4" />
      </Button>

      <div className="h-8 border-r border-gray-300 dark:border-gray-600 mx-1"></div>

      {/* Table controls */}
      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إدراج جدول"
        onClick={onInsertTable}
      >
        <Table className="h-4 w-4" />
      </Button>

      <div className="h-8 border-r border-gray-300 dark:border-gray-600 mx-1"></div>

      {/* Undo/Redo */}
      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="تراجع"
        onClick={undo}
        disabled={!canUndo}
      >
        <Undo className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إعادة"
        onClick={redo}
        disabled={!canRedo}
      >
        <Redo className="h-4 w-4" />
      </Button>

      <div className="h-8 border-r border-gray-300 dark:border-gray-600 mx-1"></div>

      {/* Other tools */}
      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إدراج صورة"
        onClick={handleInsertImage}
      >
        <Image className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إدراج موقع"
        onClick={onInsertLocation}
      >
        <MapPin className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="sm"
        className="h-8 w-8"
        title="إدراج مربع اختيار"
        onClick={handleInsertCheckbox}
      >
        <CheckSquare className="h-4 w-4" />
      </Button>

      {selectedBlockId && (
        <>
          <div className="h-8 border-r border-gray-300 dark:border-gray-600 mx-1"></div>
          <Button
            variant="outline"
            size="sm"
            className="h-8 w-8 text-red-500 hover:text-red-700"
            title="حذف العنصر المحدد"
            onClick={handleDeleteBlock}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </>
      )}

      <div className="flex-1"></div>

      {/* Import/Export buttons */}
      <Button
        variant="outline"
        size="sm"
        className="h-8"
        title="استيراد"
        onClick={onImport}
      >
        استيراد
      </Button>

      <Button
        variant="outline"
        size="sm"
        className="h-8"
        title="تصدير"
        onClick={onExport}
      >
        تصدير
      </Button>
    </div>
  );
}
