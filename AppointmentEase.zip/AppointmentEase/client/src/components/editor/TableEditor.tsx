import { useState, useRef } from 'react';
import { useDocument } from '@/contexts/DocumentContext';
import { evaluateFormula } from './TableFormulaEngine';
import { TableBlock, TableCell as TableCellType } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { 
  Plus, Trash2, ChevronDown, ArrowUpDown, 
  GripVertical, CornerDownRight 
} from 'lucide-react';

interface TableEditorProps {
  tableBlock: TableBlock;
  onOpenDropdownModal?: (tableId: string, rowIndex: number, colIndex: number) => void;
}

export default function TableEditor({ tableBlock, onOpenDropdownModal }: TableEditorProps) {
  const { 
    updateBlock, 
    removeBlock, 
    updateTableCell, 
    addTableRow, 
    removeTableRow, 
    addTableColumn, 
    removeTableColumn 
  } = useDocument();
  
  const [hoveredCell, setHoveredCell] = useState<{row: number, col: number} | null>(null);
  const [selectedCell, setSelectedCell] = useState<{row: number, col: number} | null>(null);
  const [isResizing, setIsResizing] = useState(false);
  const tableRef = useRef<HTMLTableElement>(null);
  
  // Handle cell content change
  const handleCellChange = (rowIndex: number, colIndex: number, content: string) => {
    updateTableCell(tableBlock.id, rowIndex, colIndex, { content });
    
    // Update cells with formulas that might depend on this cell
    updateFormulaCells();
  };
  
  // Update formula cells after data changes
  const updateFormulaCells = () => {
    tableBlock.rows.forEach((row, rowIndex) => {
      row.cells.forEach((cell, colIndex) => {
        if (cell.formula) {
          try {
            const result = evaluateFormula(tableBlock, cell.formula);
            updateTableCell(tableBlock.id, rowIndex, colIndex, { 
              content: result.toString() 
            });
          } catch (error) {
            console.error('Formula evaluation error:', error);
          }
        }
      });
    });
  };
  
  // Handle key press in cell (for tab navigation, enter for new row)
  const handleCellKeyDown = (
    e: React.KeyboardEvent<HTMLDivElement>, 
    rowIndex: number, 
    colIndex: number
  ) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const nextColIndex = e.shiftKey ? colIndex - 1 : colIndex + 1;
      
      if (nextColIndex < 0) {
        // Move to last cell of previous row
        if (rowIndex > 0) {
          const prevRowCells = tableBlock.rows[rowIndex - 1].cells;
          setSelectedCell({ row: rowIndex - 1, col: prevRowCells.length - 1 });
        }
      } else if (nextColIndex >= tableBlock.rows[rowIndex].cells.length) {
        // Move to first cell of next row or create new row
        if (rowIndex < tableBlock.rows.length - 1) {
          setSelectedCell({ row: rowIndex + 1, col: 0 });
        } else {
          // At the last cell of the table, add a new row
          addTableRow(tableBlock.id, rowIndex);
          setTimeout(() => {
            setSelectedCell({ row: rowIndex + 1, col: 0 });
          }, 0);
        }
      } else {
        // Move to next/previous cell in same row
        setSelectedCell({ row: rowIndex, col: nextColIndex });
      }
    } else if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      
      // Add a new row below the current one
      addTableRow(tableBlock.id, rowIndex);
      setTimeout(() => {
        setSelectedCell({ row: rowIndex + 1, col: colIndex });
      }, 0);
    }
  };
  
  // Handle cell click to select it
  const handleCellClick = (rowIndex: number, colIndex: number) => {
    setSelectedCell({ row: rowIndex, col: colIndex });
  };
  
  // Add a row at the end of the table
  const handleAddRow = () => {
    addTableRow(tableBlock.id, tableBlock.rows.length - 1);
  };
  
  // Add a column at the end of the table
  const handleAddColumn = () => {
    addTableColumn(tableBlock.id, tableBlock.rows[0].cells.length - 1);
  };
  
  // Remove the entire table
  const handleRemoveTable = () => {
    if (confirm('هل أنت متأكد من رغبتك في حذف هذا الجدول؟')) {
      removeBlock(tableBlock.id);
    }
  };
  
  // Open dropdown modal for a cell
  const handleOpenDropdown = (rowIndex: number, colIndex: number) => {
    if (onOpenDropdownModal) {
      onOpenDropdownModal(tableBlock.id, rowIndex, colIndex);
    }
  };
  
  // Determine if a cell is part of a formula result
  const isCellFormula = (cell: TableCellType) => {
    return !!cell.formula;
  };
  
  // Render formula indicator in cell if applicable
  const renderFormulaIndicator = (cell: TableCellType) => {
    if (isCellFormula(cell)) {
      return (
        <div className="absolute bottom-0 right-0 text-xs text-gray-400 dark:text-gray-500 mr-1">
          <CornerDownRight size={10} />
        </div>
      );
    }
    return null;
  };
  
  return (
    <div className="mb-8 relative">
      {/* Table controls */}
      <div className="flex justify-end mb-1 space-x-1 rtl:space-x-reverse">
        <Button 
          variant="outline" 
          size="icon" 
          className="h-6 w-6" 
          title="إضافة صف"
          onClick={handleAddRow}
        >
          <Plus className="h-3 w-3" />
        </Button>
        <Button 
          variant="outline" 
          size="icon" 
          className="h-6 w-6" 
          title="إضافة عمود"
          onClick={handleAddColumn}
        >
          <Plus className="h-3 w-3 rotate-90" />
        </Button>
        <Button 
          variant="outline" 
          size="icon" 
          className="h-6 w-6 text-red-500 hover:text-red-700" 
          title="حذف الجدول"
          onClick={handleRemoveTable}
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <table 
          ref={tableRef}
          className="w-full border-collapse"
          style={{ direction: 'rtl' }}
        >
          <tbody>
            {tableBlock.rows.map((row, rowIndex) => (
              <tr key={row.id}>
                {row.cells.map((cell, colIndex) => (
                  <td 
                    key={cell.id}
                    className={`
                      border border-gray-300 dark:border-gray-600 p-2 relative
                      ${isCellFormula(cell) ? 'bg-gray-50 dark:bg-gray-900' : ''}
                      ${selectedCell?.row === rowIndex && selectedCell?.col === colIndex 
                        ? 'outline outline-2 outline-blue-500 dark:outline-blue-400 z-10' 
                        : ''}
                      ${hoveredCell?.row === rowIndex && hoveredCell?.col === colIndex 
                        ? 'bg-gray-100 dark:bg-gray-800' 
                        : ''}
                    `}
                    colSpan={cell.colSpan}
                    rowSpan={cell.rowSpan}
                    onMouseEnter={() => setHoveredCell({ row: rowIndex, col: colIndex })}
                    onMouseLeave={() => setHoveredCell(null)}
                    style={{
                      direction: cell.direction,
                      fontFamily: cell.fontFamily,
                      fontSize: `${cell.fontSize}px`,
                      fontWeight: cell.fontWeight,
                      minWidth: '30px',
                      minHeight: '24px',
                      position: 'relative'
                    }}
                  >
                    {/* Cell content - editable unless it's a formula cell */}
                    <div
                      contentEditable={!isCellFormula(cell)}
                      suppressContentEditableWarning
                      className="outline-none min-h-[18px]"
                      onClick={() => handleCellClick(rowIndex, colIndex)}
                      onBlur={(e) => handleCellChange(rowIndex, colIndex, e.currentTarget.innerText)}
                      onKeyDown={(e) => handleCellKeyDown(e, rowIndex, colIndex)}
                      dangerouslySetInnerHTML={{ __html: cell.content }}
                    ></div>
                    
                    {/* Dropdown indicator if cell has dropdown options */}
                    {cell.dropdownOptions && (
                      <button 
                        className="absolute right-1 top-1 text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                        onClick={() => handleOpenDropdown(rowIndex, colIndex)}
                      >
                        <ChevronDown size={12} />
                      </button>
                    )}
                    
                    {/* Formula indicator */}
                    {renderFormulaIndicator(cell)}
                    
                    {/* Row and column action buttons - shown when cell is hovered */}
                    {hoveredCell?.row === rowIndex && hoveredCell?.col === colIndex && (
                      <>
                        {/* Column actions */}
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 flex bg-white dark:bg-gray-800 shadow rounded p-1 z-10 no-print">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-5 w-5" 
                            title="إضافة عمود"
                            onClick={(e) => {
                              e.stopPropagation();
                              addTableColumn(tableBlock.id, colIndex);
                            }}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-5 w-5 text-red-500 hover:text-red-700" 
                            title="حذف العمود"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('هل أنت متأكد من رغبتك في حذف هذا العمود؟')) {
                                removeTableColumn(tableBlock.id, colIndex);
                              }
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        {/* Row actions */}
                        <div className="absolute -right-6 top-1/2 transform -translate-y-1/2 flex flex-col bg-white dark:bg-gray-800 shadow rounded p-1 z-10 no-print">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-5 w-5" 
                            title="إضافة صف"
                            onClick={(e) => {
                              e.stopPropagation();
                              addTableRow(tableBlock.id, rowIndex);
                            }}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-5 w-5 text-red-500 hover:text-red-700" 
                            title="حذف الصف"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('هل أنت متأكد من رغبتك في حذف هذا الصف؟')) {
                                removeTableRow(tableBlock.id, rowIndex);
                              }
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
