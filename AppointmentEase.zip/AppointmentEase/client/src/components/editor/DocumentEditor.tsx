import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useEditor } from '@/contexts/EditorContext';
import A4Paper from './A4Paper';
import ElementControls from '../ElementControls';
import MapControls from '../MapControls';
import { evaluateFormula } from '@/lib/utils';

export default function DocumentEditor() {
  const { state, dispatch, saveDocument } = useEditor();
  const editorRef = useRef<HTMLDivElement>(null);
  
  // Handle content changes
  const handleContentChange = () => {
    if (!editorRef.current || !state.currentDocument) return;
    
    const content = editorRef.current.innerHTML;
    
    // Only update if content actually changed
    if (content !== state.currentDocument.content) {
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: content 
      });
    }
  };
  
  // Handle saving document or template
  const handleSaveDocument = async () => {
    await saveDocument(false);
  };
  
  const handleSaveTemplate = async () => {
    await saveDocument(true);
  };
  
  // Add event listeners for content changes
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) return;
    
    // Set up mutation observer to detect changes
    const observer = new MutationObserver(() => {
      handleContentChange();
    });
    
    // Configure observer to watch for all changes
    observer.observe(editor, {
      childList: true,
      attributes: true,
      characterData: true,
      subtree: true
    });
    
    // Add event listener for formulas in tables
    editor.addEventListener('input', (e) => {
      const target = e.target as HTMLElement;
      
      // Check if we're editing a table cell
      if (target.tagName === 'TD' && target.textContent?.trim().startsWith('=')) {
        const formula = target.textContent.trim();
        
        // Find the table this cell belongs to
        const table = target.closest('table');
        if (!table) return;
        
        // Get all table cells to use for formula evaluation
        const rows = Array.from(table.querySelectorAll('tr'));
        const tableData = rows.map(row => 
          Array.from(row.querySelectorAll('td')).map(cell => ({
            id: cell.id || '',
            content: cell.textContent || ''
          }))
        );
        
        // Evaluate the formula
        try {
          const result = evaluateFormula(formula, tableData);
          
          // Store the formula as a data attribute and display the result
          target.dataset.formula = formula;
          target.textContent = result.toString();
        } catch (error) {
          console.error('Error evaluating formula:', error);
        }
      }
    });
    
    // Clean up
    return () => {
      observer.disconnect();
    };
  }, [state.currentDocument]);
  
  return (
    <div className="flex-1 flex flex-col">
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-wrap items-center justify-between">
            <div className="flex items-center space-x-4 space-x-reverse">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                {state.currentDocument?.title || 'مستند جديد'}
              </h2>
              <div className="text-sm text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">A4</div>
            </div>
            
            <div className="flex space-x-2 space-x-reverse">
              <Button
                variant="default"
                onClick={handleSaveTemplate}
              >
                حفظ كنموذج
              </Button>
              <Button
                variant="outline"
                onClick={handleSaveDocument}
              >
                حفظ المستند
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex-1 bg-gray-200 dark:bg-gray-800 rounded-lg shadow-md overflow-auto flex justify-center p-8 relative">
        <ElementControls />
        <MapControls />
        <A4Paper editorRef={editorRef} />
      </div>
    </div>
  );
}
