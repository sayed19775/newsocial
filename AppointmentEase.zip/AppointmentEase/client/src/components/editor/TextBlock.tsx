import { useState, useRef, useEffect } from 'react';
import { useDocument } from '@/contexts/DocumentContext';
import { TextBlock as TextBlockType } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Bold, Italic, AlignRight, AlignLeft, Trash2 } from 'lucide-react';

interface TextBlockProps {
  block: TextBlockType;
}

export default function TextBlock({ block }: TextBlockProps) {
  const { updateBlock, removeBlock } = useDocument();
  const [isEditing, setIsEditing] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  
  // Update content of the block when it changes
  const handleContentChange = () => {
    if (contentRef.current) {
      updateBlock(block.id, {
        ...block,
        content: contentRef.current.innerText,
      });
    }
  };
  
  // Handle text direction toggle
  const toggleDirection = () => {
    updateBlock(block.id, {
      ...block,
      direction: block.direction === 'rtl' ? 'ltr' : 'rtl',
    });
  };
  
  // Handle text style - bold toggle
  const toggleBold = () => {
    updateBlock(block.id, {
      ...block,
      fontWeight: block.fontWeight === 'normal' ? 'bold' : 'normal',
    });
  };
  
  // Delete this text block
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('هل أنت متأكد من رغبتك في حذف هذا النص؟')) {
      removeBlock(block.id);
    }
  };
  
  // Styles based on block properties
  const blockStyles = {
    direction: block.direction,
    fontFamily: block.fontFamily,
    fontSize: `${block.fontSize}px`,
    fontWeight: block.fontWeight,
  };
  
  return (
    <div 
      className="relative mb-4 group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Text editing controls - visible on hover */}
      {isHovered && (
        <div className="absolute -top-8 right-0 flex bg-white dark:bg-gray-800 shadow rounded p-1 z-10 no-print">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6" 
            onClick={toggleBold}
          >
            <Bold className="h-3 w-3" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6" 
            onClick={toggleDirection}
          >
            {block.direction === 'rtl' ? (
              <AlignRight className="h-3 w-3" />
            ) : (
              <AlignLeft className="h-3 w-3" />
            )}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 text-red-500 hover:text-red-700" 
            onClick={handleDelete}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      )}
      
      {/* Editable text content */}
      <div
        ref={contentRef}
        contentEditable
        suppressContentEditableWarning
        className={`
          p-2 min-h-[24px] border border-transparent rounded
          ${isEditing ? 'border-gray-300 dark:border-gray-600' : ''}
          ${isHovered ? 'outline-dashed outline-1 outline-gray-300 dark:outline-gray-600' : ''}
          focus:outline-none focus:border-blue-300 dark:focus:border-blue-500
        `}
        style={blockStyles}
        onClick={() => setIsEditing(true)}
        onBlur={() => {
          setIsEditing(false);
          handleContentChange();
        }}
        onInput={handleContentChange}
        dangerouslySetInnerHTML={{ __html: block.content }}
      ></div>
    </div>
  );
}
