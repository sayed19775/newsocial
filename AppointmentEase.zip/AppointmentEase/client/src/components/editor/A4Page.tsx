import { useState, useRef, useEffect } from 'react';
import { useDocument } from '@/contexts/DocumentContext';
import TextBlock from './TextBlock';
import TableEditor from './TableEditor';

interface A4PageProps {
  onOpenDropdownModal?: (tableId: string, rowIndex: number, colIndex: number) => void;
}

export default function A4Page({ onOpenDropdownModal }: A4PageProps) {
  const { documentState, setTitle } = useDocument();
  const pageRef = useRef<HTMLDivElement>(null);
  const [isEditing, setIsEditing] = useState(false);
  
  // Handle title change
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };
  
  // Focus out of edit mode when clicking outside the page
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (pageRef.current && !pageRef.current.contains(event.target as Node)) {
        setIsEditing(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Render a block based on its type
  const renderBlock = (block: any) => {
    switch (block.type) {
      case 'text':
        return <TextBlock key={block.id} block={block} />;
      case 'table':
        return <TableEditor 
          key={block.id} 
          tableBlock={block} 
          onOpenDropdownModal={onOpenDropdownModal} 
        />;
      case 'image':
        return (
          <div key={block.id} className="mb-4 flex justify-center">
            <img 
              src={block.src} 
              alt={block.alt || ''} 
              style={{ 
                maxWidth: '100%', 
                width: `${block.width}px`, 
                height: `${block.height}px`, 
                objectFit: 'contain' 
              }} 
            />
          </div>
        );
      case 'location':
        return (
          <div key={block.id} className="mb-4 border p-4 rounded">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-bold">الموقع</h3>
            </div>
            <div className="h-40 bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
              <div className="text-center">
                <div>{block.address || 'بدون عنوان'}</div>
                <div className="text-sm text-gray-500">
                  {block.latitude}, {block.longitude}
                </div>
              </div>
            </div>
          </div>
        );
      case 'checkbox':
        return (
          <div key={block.id} className="mb-4 flex items-center">
            <input 
              type="checkbox" 
              checked={block.checked} 
              className="ml-2 h-4 w-4" 
              onChange={() => {
                // Update checkbox state
              }}
            />
            <span>{block.label}</span>
            {block.excludeFromPrint && (
              <span className="text-xs text-gray-500 mr-2">(لن يظهر عند الطباعة)</span>
            )}
          </div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div 
      ref={pageRef}
      className="a4-page bg-white dark:bg-gray-800 shadow-lg mx-auto my-8"
      style={{
        width: '210mm',
        height: '297mm',
        padding: '0.5cm',
        direction: documentState.direction,
      }}
      onClick={() => setIsEditing(true)}
    >
      <div className="mb-6 text-center">
        {isEditing ? (
          <input
            type="text"
            value={documentState.title}
            onChange={handleTitleChange}
            className="text-2xl font-bold border-b-2 border-dashed border-gray-300 dark:border-gray-600 w-full text-center bg-transparent outline-none"
          />
        ) : (
          <h1 className="text-2xl font-bold">{documentState.title}</h1>
        )}
      </div>
      
      {documentState.blocks.length === 0 ? (
        <div className="h-full flex items-center justify-center text-gray-400 dark:text-gray-500">
          <p className="text-center">انقر على أدوات التحرير في الشريط الجانبي لإضافة محتوى</p>
        </div>
      ) : (
        <div className="document-content">
          {documentState.blocks.map(block => renderBlock(block))}
        </div>
      )}
    </div>
  );
}
