import { useEffect, RefObject } from 'react';
import { useEditor } from '@/contexts/EditorContext';

interface A4PaperProps {
  editorRef: RefObject<HTMLDivElement>;
}

export default function A4Paper({ editorRef }: A4PaperProps) {
  const { state, dispatch } = useEditor();
  
  // Initialize with document content when it changes
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor || !state.currentDocument) return;
    
    // Set the content
    editor.innerHTML = state.currentDocument.content;
    
    // Make the editor focusable
    editor.setAttribute('contenteditable', 'true');
    
    // Set initial document state
    editor.dir = state.textDirection;
    editor.className = `editor-content ${state.fontFamily}`;
    editor.style.fontSize = `${state.fontSize}px`;
    
    // Focus at the end of the content
    const selection = window.getSelection();
    if (selection) {
      const range = document.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
      editor.focus();
    }
  }, [state.currentDocument?.id]);
  
  // Handle editor clicks
  const handleEditorClick = (e: React.MouseEvent) => {
    // If the user clicks on the empty editor, create a default paragraph
    const editor = editorRef.current;
    if (!editor || editor.innerHTML.trim() !== '') return;
    
    const p = document.createElement('p');
    p.dir = state.textDirection;
    editor.appendChild(p);
    
    // Position cursor in the new paragraph
    const selection = window.getSelection();
    if (selection) {
      const range = document.createRange();
      range.setStart(p, 0);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  };
  
  // Handle content paste to clean up formatting
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    
    // Get plain text
    const text = e.clipboardData.getData('text/plain');
    
    // Insert at cursor position
    document.execCommand('insertText', false, text);
  };
  
  // Handle keyboard shortcuts
  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Undo - Ctrl+Z
    if (e.ctrlKey && e.key === 'z') {
      e.preventDefault();
      if (state.undoStack.length > 0) {
        dispatch({ type: 'UNDO' });
      }
    }
    
    // Redo - Ctrl+Y or Ctrl+Shift+Z
    if ((e.ctrlKey && e.key === 'y') || (e.ctrlKey && e.shiftKey && e.key === 'z')) {
      e.preventDefault();
      if (state.redoStack.length > 0) {
        dispatch({ type: 'REDO' });
      }
    }
    
    // Bold - Ctrl+B
    if (e.ctrlKey && e.key === 'b') {
      e.preventDefault();
      document.execCommand('bold', false);
      dispatch({ type: 'TOGGLE_BOLD' });
    }
    
    // Italic - Ctrl+I
    if (e.ctrlKey && e.key === 'i') {
      e.preventDefault();
      document.execCommand('italic', false);
      dispatch({ type: 'TOGGLE_ITALIC' });
    }
    
    // Underline - Ctrl+U
    if (e.ctrlKey && e.key === 'u') {
      e.preventDefault();
      document.execCommand('underline', false);
      dispatch({ type: 'TOGGLE_UNDERLINE' });
    }
  };
  
  return (
    <div className="paper">
      <div 
        ref={editorRef}
        id="documentEditor"
        className={`editor-content ${state.fontFamily}`}
        dir={state.textDirection}
        onClick={handleEditorClick}
        onPaste={handlePaste}
        onKeyDown={handleKeyDown}
        style={{ fontSize: `${state.fontSize}px` }}
      />
    </div>
  );
}
