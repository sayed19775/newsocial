import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useEditor } from "@/contexts/EditorContext";

export default function MapControls() {
  const [selectedMap, setSelectedMap] = useState<HTMLDivElement | null>(null);
  const { state, dispatch } = useEditor();

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Check if we clicked on a map wrapper or its children
      const mapWrapper = target.closest(".location-element");
      
      if (mapWrapper) {
        setSelectedMap(mapWrapper as HTMLDivElement);
      } else {
        setSelectedMap(null);
      }
    };

    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  const deleteMap = () => {
    if (selectedMap && state.currentDocument) {
      // Save current state to undo stack
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
      
      // Remove the map
      selectedMap.remove();
      setSelectedMap(null);
      
      // Update document content
      const editor = document.getElementById('documentEditor');
      if (editor) {
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }
    }
  };

  const setMapSize = (height: string) => {
    if (selectedMap && state.currentDocument) {
      // Save current state to undo stack
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
      
      // Resize the map
      const img = selectedMap.querySelector("img");
      if (img) {
        img.style.maxHeight = height;
        img.style.height = height;
      }
      
      // Update document content
      const editor = document.getElementById('documentEditor');
      if (editor) {
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }
    }
  };

  if (!selectedMap) return null;

  // Calculate position for the controls
  const rect = selectedMap.getBoundingClientRect();
  const controlsStyle = {
    position: 'absolute' as const,
    top: `${rect.top + window.scrollY - 40}px`,
    left: `${rect.left + window.scrollX}px`,
    zIndex: 1000,
  };

  return (
    <div 
      className="bg-white shadow-md rounded border px-3 py-1 flex items-center gap-2"
      style={controlsStyle}
    >
      <div className="text-xs text-gray-600">تحديد موقع</div>
      <Button 
        variant="outline" 
        size="sm" 
        className="h-7 text-xs"
        onClick={() => setMapSize("150px")}
      >
        صغير
      </Button>
      <Button 
        variant="outline" 
        size="sm" 
        className="h-7 text-xs"
        onClick={() => setMapSize("250px")}
      >
        متوسط
      </Button>
      <Button 
        variant="outline" 
        size="sm" 
        className="h-7 text-xs"
        onClick={() => setMapSize("350px")}
      >
        كبير
      </Button>
      <Button 
        variant="destructive" 
        size="sm" 
        className="h-7 text-xs"
        onClick={deleteMap}
      >
        حذف
      </Button>
    </div>
  );
}