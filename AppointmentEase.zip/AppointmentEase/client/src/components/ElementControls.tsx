import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useEditor } from "@/contexts/EditorContext";

export default function ElementControls() {
  const [selectedElement, setSelectedElement] = useState<HTMLElement | null>(null);
  const { state, dispatch } = useEditor();
  
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Check if we clicked on table, text-box, image, location
      const isTable = target.closest('table');
      const isTextBox = target.closest('.text-box-container');
      const isLocation = target.closest('.location-element');
      const isImage = target.tagName === 'IMG' || target.closest('img');
      
      if (isTable || isTextBox || isLocation || isImage) {
        // Find the main container element
        const element = isTable || isTextBox || isLocation || 
                       (isImage ? (target.tagName === 'IMG' ? target : target.closest('img')) : null);
        
        if (element) {
          setSelectedElement(element as HTMLElement);
          return;
        }
      }
      
      // If we click elsewhere, deselect
      setSelectedElement(null);
    };
    
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);
  
  const handleDelete = () => {
    if (!selectedElement || !state.currentDocument) return;
    
    // Save current content to undo stack
    const editor = document.getElementById('documentEditor');
    if (editor) {
      dispatch({ 
        type: 'ADD_TO_UNDO_STACK', 
        payload: state.currentDocument.content 
      });
      
      // Remove the element
      selectedElement.remove();
      
      // Update document content
      dispatch({ 
        type: 'UPDATE_DOCUMENT_CONTENT', 
        payload: editor.innerHTML 
      });
      
      // Clear selection
      setSelectedElement(null);
    }
  };
  
  if (!selectedElement) return null;
  
  // Calculate position for the controls
  const rect = selectedElement.getBoundingClientRect();
  const controlsStyle = {
    position: 'absolute' as const,
    top: `${rect.top + window.scrollY - 40}px`,
    left: `${rect.left + window.scrollX}px`,
    zIndex: 1000,
  };
  
  // Determine element type for controls label
  let elementType = 'عنصر';
  if (selectedElement.tagName === 'TABLE') elementType = 'جدول';
  else if (selectedElement.classList.contains('text-box-container')) elementType = 'مربع نص';
  else if (selectedElement.classList.contains('location-element')) elementType = 'موقع';
  else if (selectedElement.tagName === 'IMG') elementType = 'صورة';
  
  return (
    <div 
      className="bg-white shadow-md rounded border px-3 py-1 flex items-center gap-2"
      style={controlsStyle}
    >
      <div className="text-xs text-gray-600">تحديد {elementType}</div>
      <Button 
        variant="destructive" 
        size="sm" 
        className="h-7 text-xs"
        onClick={handleDelete}
      >
        حذف
      </Button>
    </div>
  );
}