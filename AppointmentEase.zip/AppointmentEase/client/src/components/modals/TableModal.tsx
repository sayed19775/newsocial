import { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useEditor } from '@/contexts/EditorContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

interface TableModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TableModal({ isOpen, onClose }: TableModalProps) {
  const [rows, setRows] = useState(3);
  const [columns, setColumns] = useState(3);
  const [hasBorders, setHasBorders] = useState(true);
  const [hasHeader, setHasHeader] = useState(true);
  const [enableFormulas, setEnableFormulas] = useState(true);
  const [activeTab, setActiveTab] = useState('basic');
  const { state, dispatch } = useEditor();
  
  // Function to create a cell ID
  const createCellId = (rowIndex: number, colIndex: number) => {
    return `cell-${rowIndex}-${colIndex}`;
  };
  
  // Function to handle cell merge
  const mergeCells = (
    table: HTMLTableElement, 
    startRow: number, 
    startCol: number, 
    endRow: number, 
    endCol: number
  ) => {
    const rowSpan = endRow - startRow + 1;
    const colSpan = endCol - startCol + 1;
    
    // Get the cell at the start position
    const cell = table.rows[startRow].cells[startCol];
    
    // Set rowSpan and colSpan
    cell.rowSpan = rowSpan;
    cell.colSpan = colSpan;
    
    // Remove other cells that are now covered
    for (let i = startRow; i <= endRow; i++) {
      for (let j = startCol; j <= endCol; j++) {
        if (i === startRow && j === startCol) continue; // Skip the first cell
        
        // Remove the cell
        const row = table.rows[i];
        const cellIndex = j - (i === startRow ? startCol + 1 : 0);
        if (row && row.cells[cellIndex]) {
          row.deleteCell(cellIndex);
        }
      }
    }
  };
  
  // Create a context menu for the table cells
  const createContextMenu = () => {
    // Create the context menu container
    const contextMenu = document.createElement('div');
    contextMenu.className = 'table-context-menu';
    contextMenu.style.position = 'absolute';
    contextMenu.style.display = 'none';
    contextMenu.style.backgroundColor = 'white';
    contextMenu.style.border = '1px solid #ccc';
    contextMenu.style.borderRadius = '4px';
    contextMenu.style.padding = '5px';
    contextMenu.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    contextMenu.style.zIndex = '1000';
    
    // Create menu items
    const menuItems = [
      { text: 'دمج الخلايا', action: 'merge' },
      { text: 'إضافة صيغة', action: 'formula' },
      { text: 'إضافة قائمة منسدلة', action: 'dropdown' },
      { text: 'حذف الصف', action: 'deleteRow' },
      { text: 'حذف العمود', action: 'deleteColumn' },
      { text: 'إضافة صف', action: 'addRow' },
      { text: 'إضافة عمود', action: 'addColumn' },
    ];
    
    menuItems.forEach(item => {
      const menuItem = document.createElement('div');
      menuItem.textContent = item.text;
      menuItem.className = 'context-menu-item';
      menuItem.style.padding = '8px 12px';
      menuItem.style.cursor = 'pointer';
      menuItem.style.transition = 'background-color 0.2s';
      
      // Add hover effect
      menuItem.addEventListener('mouseover', () => {
        menuItem.style.backgroundColor = '#f3f4f6';
      });
      
      menuItem.addEventListener('mouseout', () => {
        menuItem.style.backgroundColor = 'transparent';
      });
      
      // Add the menuItem to contextMenu
      contextMenu.appendChild(menuItem);
      
      // Add a divider (except after the last item)
      if (item !== menuItems[menuItems.length - 1]) {
        const divider = document.createElement('div');
        divider.style.height = '1px';
        divider.style.backgroundColor = '#e5e7eb';
        divider.style.margin = '2px 0';
        contextMenu.appendChild(divider);
      }
    });
    
    return contextMenu;
  };
  
  // Function to add formula support to a cell
  const addFormulaSupport = (cell: HTMLTableCellElement, tableId: string, rowIndex: number, colIndex: number) => {
    // Add attributes to identify the cell
    cell.dataset.row = rowIndex.toString();
    cell.dataset.col = colIndex.toString();
    cell.dataset.id = createCellId(rowIndex, colIndex);
    cell.dataset.tableId = tableId;
    
    // Allow formula input by prefixing with =
    cell.addEventListener('input', () => {
      const content = cell.textContent || '';
      if (content.startsWith('=')) {
        cell.dataset.formula = content;
        cell.classList.add('has-formula');
        
        try {
          // Basic formula evaluation (to be expanded)
          const formula = content.substring(1); // Remove the =
          
          // Find all cell references in the formula (like A1, B2, etc.)
          const cellReferences = formula.match(/[A-Z]+[0-9]+/g) || [];
          
          // For each reference, get the value
          let evaluatedFormula = formula;
          cellReferences.forEach(ref => {
            const colLetter = ref.match(/[A-Z]+/)?.[0] || '';
            const rowNumber = parseInt(ref.match(/[0-9]+/)?.[0] || '0') - 1;
            const colNumber = colLetter.charCodeAt(0) - 65; // A=0, B=1, etc.
            
            // Find the referenced cell
            const refCell = document.querySelector(`[data-table-id="${tableId}"][data-row="${rowNumber}"][data-col="${colNumber}"]`);
            
            if (refCell) {
              const cellValue = (refCell as HTMLElement).textContent || '0';
              // Replace the reference with the value
              evaluatedFormula = evaluatedFormula.replace(ref, cellValue);
            }
          });
          
          // Evaluate the formula (using Function instead of eval for security)
          const result = new Function(`return ${evaluatedFormula}`)();
          
          // Update the cell's display value (but keep the formula as data attribute)
          cell.textContent = result.toString();
        } catch (error) {
          // If there's an error in the formula, show the formula itself
          console.error('Formula error:', error);
        }
      } else {
        // If it's not a formula, remove the formula data attribute
        delete cell.dataset.formula;
        cell.classList.remove('has-formula');
      }
    });
    
    // Show the formula on focus if it exists
    cell.addEventListener('focus', () => {
      if (cell.dataset.formula) {
        cell.textContent = cell.dataset.formula;
      }
    });
    
    // Recompute formula on blur
    cell.addEventListener('blur', () => {
      const content = cell.textContent || '';
      if (content.startsWith('=')) {
        // Trigger the input event to recalculate
        const event = new Event('input', { bubbles: true });
        cell.dispatchEvent(event);
      }
    });
  };
  
  // Add utility function to style tables
  const styleTable = (table: HTMLTableElement) => {
    // Add a class to identify the table
    const tableId = `table-${Date.now()}`;
    table.id = tableId;
    table.className = 'document-table';
    table.style.width = '100%';
    table.style.marginTop = '10px';
    table.style.marginBottom = '10px';
    table.style.borderCollapse = 'collapse';
    
    if (hasBorders) {
      table.style.border = '1px solid #e2e8f0';
    }
    
    // Make table resizable
    makeTableResizable(table);
    
    return tableId;
  };
  
  // Function to add row numbers
  const addRowNumbers = (table: HTMLTableElement) => {
    // Insert a new column at the beginning for row numbers
    for (let i = 0; i < table.rows.length; i++) {
      const row = table.rows[i];
      const cell = row.insertCell(0);
      cell.textContent = (i + 1).toString();
      cell.style.backgroundColor = '#f1f5f9';
      cell.style.fontWeight = 'bold';
      cell.style.textAlign = 'center';
      cell.style.width = '40px';
      cell.contentEditable = 'false';
    }
  };
  
  // Function to make the table resizable
  const makeTableResizable = (table: HTMLTableElement) => {
    // Add a resize handle to the table
    const resizeHandle = document.createElement('div');
    resizeHandle.className = 'table-resize-handle';
    resizeHandle.style.position = 'absolute';
    resizeHandle.style.bottom = '0';
    resizeHandle.style.right = '0';
    resizeHandle.style.width = '10px';
    resizeHandle.style.height = '10px';
    resizeHandle.style.backgroundColor = '#4299e1';
    resizeHandle.style.cursor = 'nwse-resize';
    resizeHandle.style.borderRadius = '50%';
    
    // Create a wrapper for the table to position the resize handle
    const wrapper = document.createElement('div');
    wrapper.style.position = 'relative';
    wrapper.style.display = 'inline-block';
    wrapper.style.width = '100%';
    
    // Add the table to the wrapper
    table.parentNode?.insertBefore(wrapper, table);
    wrapper.appendChild(table);
    wrapper.appendChild(resizeHandle);
    
    // Add event listeners for resizing
    resizeHandle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      
      const startX = e.clientX;
      const startY = e.clientY;
      const startWidth = table.offsetWidth;
      
      const handleMouseMove = (moveEvent: MouseEvent) => {
        const dx = moveEvent.clientX - startX;
        const newWidth = startWidth + dx;
        table.style.width = `${newWidth}px`;
      };
      
      const handleMouseUp = () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
      
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    });
    
    // Allow columns to be resizable
    makeColumnsResizable(table);
  };
  
  // Function to make table columns resizable
  const makeColumnsResizable = (table: HTMLTableElement) => {
    // Add resize handles between each column header
    const headerRow = table.rows[0];
    if (!headerRow) return;
    
    // Only add resize handles if we have more than one column (excluding row numbers column)
    if (headerRow.cells.length <= 1) return;
    
    // For each column (except the last one)
    for (let i = 0; i < headerRow.cells.length - 1; i++) {
      const cell = headerRow.cells[i];
      const handle = document.createElement('div');
      
      handle.className = 'column-resize-handle';
      handle.style.position = 'absolute';
      handle.style.top = '0';
      handle.style.right = '0';
      handle.style.width = '5px';
      handle.style.height = '100%';
      handle.style.cursor = 'col-resize';
      handle.style.zIndex = '1';
      
      // Position it relative to the cell
      cell.style.position = 'relative';
      cell.appendChild(handle);
      
      // Add resize functionality
      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const startX = e.clientX;
        const startWidth = cell.offsetWidth;
        
        const handleMouseMove = (moveEvent: MouseEvent) => {
          const dx = moveEvent.clientX - startX;
          cell.style.width = `${startWidth + dx}px`;
        };
        
        const handleMouseUp = () => {
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
        };
        
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
      });
    }
  };
  
  // Handle creating the table
  const handleCreateTable = () => {
    // Instead of directly inserting the table into the DOM, we'll use the Document Context
    // to add a table block to the document state
    const { addTableBlock } = window.documentContextActions || {};
    
    if (addTableBlock) {
      // Use the Document Context API to add a table block
      addTableBlock(rows, columns, {
        hasBorders,
        hasHeader,
        enableFormulas,
      });
      
      // Close the modal
      onClose();
      
      // Log success
      console.log('تم إنشاء جدول بنجاح!', { rows, columns, hasBorders, hasHeader, enableFormulas });
      return;
    }
    
    // Fallback method using direct DOM manipulation if the context is not available
    console.log('Falling back to direct DOM manipulation for table insertion');
    
    const editor = document.querySelector('[contenteditable="true"]');
    if (!editor || !state.currentDocument) {
      console.error('No editable element found or no current document');
      return;
    }
    
    // Create table element
    const table = document.createElement('table');
    const tableId = styleTable(table);
    
    // Create header if enabled
    if (hasHeader) {
      const thead = document.createElement('thead');
      const headerRow = document.createElement('tr');
      
      for (let j = 0; j < columns; j++) {
        const th = document.createElement('th');
        th.contentEditable = 'true';
        th.textContent = `عمود ${j + 1}`;
        th.style.backgroundColor = '#f8fafc';
        th.style.fontWeight = 'bold';
        th.style.padding = '8px';
        th.style.textAlign = 'center';
        
        if (hasBorders) {
          th.style.border = '1px solid #e2e8f0';
        }
        
        headerRow.appendChild(th);
      }
      
      thead.appendChild(headerRow);
      table.appendChild(thead);
    }
    
    // Create table body
    const tbody = document.createElement('tbody');
    
    // Create rows and cells
    for (let i = 0; i < rows; i++) {
      const tr = document.createElement('tr');
      
      for (let j = 0; j < columns; j++) {
        const td = document.createElement('td');
        td.contentEditable = 'true';
        td.textContent = '';
        td.style.padding = '8px';
        
        if (hasBorders) {
          td.style.border = '1px solid #e2e8f0';
        }
        
        // Add formula support if enabled
        if (enableFormulas) {
          addFormulaSupport(td, tableId, i, j);
        }
        
        // Add context menu for cells
        td.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          
          // Remove any existing context menus
          const existingMenus = document.querySelectorAll('.table-context-menu');
          existingMenus.forEach(menu => menu.remove());
          
          // Create and show context menu
          const contextMenu = createContextMenu();
          document.body.appendChild(contextMenu);
          
          // Position the menu at the mouse position
          contextMenu.style.left = `${e.clientX}px`;
          contextMenu.style.top = `${e.clientY}px`;
          contextMenu.style.display = 'block';
          
          // Get the current cell's position
          const rowIndex = i;
          const colIndex = j;
          
          // Handle menu item clicks
          const menuItems = contextMenu.querySelectorAll('.context-menu-item');
          menuItems.forEach((item, index) => {
            item.addEventListener('click', () => {
              switch (index) {
                case 0: // Merge cells
                  // For now, just merge 2x2 cells as an example
                  if (i < rows - 1 && j < columns - 1) {
                    mergeCells(table, i, j, i + 1, j + 1);
                  }
                  break;
                case 1: // Add formula
                  td.focus();
                  td.textContent = '=';
                  break;
                case 2: // Add dropdown
                  // Create a dropdown in the cell
                  td.innerHTML = '';
                  
                  const select = document.createElement('select');
                  select.style.width = '100%';
                  select.style.padding = '5px';
                  select.style.border = 'none';
                  select.style.background = 'transparent';
                  
                  // Add some example options
                  ['اختر...', 'خيار 1', 'خيار 2', 'خيار 3'].forEach(option => {
                    const opt = document.createElement('option');
                    opt.value = option;
                    opt.textContent = option;
                    select.appendChild(opt);
                  });
                  
                  td.appendChild(select);
                  td.contentEditable = 'false';
                  break;
                case 3: // Delete row
                  if (table.rows.length > 1) {
                    table.deleteRow(i + (hasHeader ? 1 : 0));
                  }
                  break;
                case 4: // Delete column
                  if (columns > 1) {
                    // Delete the column from each row
                    for (let k = 0; k < table.rows.length; k++) {
                      table.rows[k].deleteCell(j);
                    }
                  }
                  break;
                case 5: // Add row
                  const newRow = table.insertRow(i + 1 + (hasHeader ? 1 : 0));
                  
                  // Add cells to the new row
                  for (let k = 0; k < columns; k++) {
                    const cell = newRow.insertCell(k);
                    cell.contentEditable = 'true';
                    
                    if (hasBorders) {
                      cell.style.border = '1px solid #e2e8f0';
                    }
                    cell.style.padding = '8px';
                    
                    // Add formula support if enabled
                    if (enableFormulas) {
                      addFormulaSupport(cell, tableId, i + 1, k);
                    }
                  }
                  break;
                case 6: // Add column
                  // Add a cell to each row
                  for (let k = 0; k < table.rows.length; k++) {
                    const row = table.rows[k];
                    const cell = row.insertCell(j + 1);
                    
                    if (k === 0 && hasHeader) {
                      cell.textContent = `عمود ${columns + 1}`;
                      cell.style.backgroundColor = '#f8fafc';
                      cell.style.fontWeight = 'bold';
                    } else {
                      cell.contentEditable = 'true';
                    }
                    
                    if (hasBorders) {
                      cell.style.border = '1px solid #e2e8f0';
                    }
                    cell.style.padding = '8px';
                    
                    // Add formula support if enabled
                    if (enableFormulas) {
                      addFormulaSupport(cell, tableId, k - (hasHeader ? 1 : 0), j + 1);
                    }
                  }
                  break;
              }
              
              // Close the context menu
              contextMenu.remove();
              
              // Update the document content
              if (editor) {
                dispatch({ 
                  type: 'UPDATE_DOCUMENT_CONTENT', 
                  payload: editor.innerHTML 
                });
              }
            });
          });
          
          // Close the menu when clicking elsewhere
          document.addEventListener('click', () => {
            contextMenu.remove();
          }, { once: true });
        });
        
        tr.appendChild(td);
      }
      
      tbody.appendChild(tr);
    }
    
    table.appendChild(tbody);
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Mark the table with a special class to make it easier to identify
    table.className = 'document-table dynamic-table';
    
    // Insert the table at cursor position or at the end
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(table);
      
      // Ensure we see the table by forcing a layout update
      setTimeout(() => {
        table.style.display = 'table';
        
        // Update document content
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }, 50);
    } else {
      editor.appendChild(table);
      
      // Ensure we see the table by forcing a layout update
      setTimeout(() => {
        table.style.display = 'table';
        
        // Update document content
        dispatch({ 
          type: 'UPDATE_DOCUMENT_CONTENT', 
          payload: editor.innerHTML 
        });
      }, 50);
    }
    
    // Close the modal
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-right">إدراج جدول جديد</DialogTitle>
          <DialogDescription className="text-right">
            قم بإعداد الجدول حسب احتياجاتك، يمكن التعديل لاحقاً من خلال القائمة المنسدلة على يمين الخلايا.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="basic" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="basic">إعدادات أساسية</TabsTrigger>
            <TabsTrigger value="advanced">إعدادات متقدمة</TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic" className="space-y-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="rows" className="text-right col-span-1">
                عدد الصفوف
              </Label>
              <Input
                id="rows"
                type="number"
                min={1}
                max={20}
                value={rows}
                onChange={(e) => setRows(parseInt(e.target.value) || 1)}
                className="col-span-3"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="columns" className="text-right col-span-1">
                عدد الأعمدة
              </Label>
              <Input
                id="columns"
                type="number"
                min={1}
                max={10}
                value={columns}
                onChange={(e) => setColumns(parseInt(e.target.value) || 1)}
                className="col-span-3"
              />
            </div>
            
            <div className="flex items-center justify-end space-x-2 space-x-reverse pt-2">
              <Label htmlFor="header-switch" className="mr-2">إضافة عناوين</Label>
              <Switch 
                id="header-switch" 
                checked={hasHeader}
                onCheckedChange={setHasHeader}
              />
            </div>
            
            <div className="flex items-center justify-end space-x-2 space-x-reverse">
              <Label htmlFor="borders-switch" className="mr-2">إضافة حدود للجدول</Label>
              <Switch 
                id="borders-switch" 
                checked={hasBorders}
                onCheckedChange={setHasBorders}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="advanced" className="space-y-4 py-4">
            <div className="flex items-center justify-end space-x-2 space-x-reverse">
              <Label htmlFor="formulas-switch" className="mr-2">تمكين الصيغ الحسابية</Label>
              <Switch 
                id="formulas-switch" 
                checked={enableFormulas}
                onCheckedChange={setEnableFormulas}
              />
            </div>
            
            {enableFormulas && (
              <div className="rounded-md bg-muted p-4 mt-2">
                <h4 className="text-sm font-medium mb-2 text-right">تعليمات الصيغ الحسابية</h4>
                <ul className="text-sm list-disc list-inside space-y-1 text-right">
                  <li>ابدأ الصيغة بعلامة = مثل =1+2 أو =A1+B1</li>
                  <li>استخدم معرفات الخلايا مثل A1 للإشارة لمحتوى الخلايا الأخرى</li>
                  <li>يمكنك استخدام العمليات الحسابية +, -, *, /</li>
                  <li>انقر بزر الماوس الأيمن على الخلية لفتح قائمة الخيارات</li>
                </ul>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="sm:justify-start">
          <div className="flex flex-row-reverse w-full justify-start gap-2">
            <Button type="submit" onClick={handleCreateTable}>إدراج</Button>
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
