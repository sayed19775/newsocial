import { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import { useEditor } from '@/contexts/EditorContext';
import { LocationData } from '@/types';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LocationModal({ isOpen, onClose }: LocationModalProps) {
  const [locationTab, setLocationTab] = useState('coordinates');
  const [lat, setLat] = useState('');
  const [lng, setLng] = useState('');
  const [telegramLink, setTelegramLink] = useState('');
  const { state, dispatch } = useEditor();
  
  // Reset form when modal opens
  const resetForm = () => {
    setLocationTab('coordinates');
    setLat('');
    setLng('');
    setTelegramLink('');
  };
  
  // Extract coordinates from Telegram link
  const extractCoordinatesFromTelegram = (link: string): [string, string] | null => {
    // Example Telegram location link: https://t.me/share/url?url=https%3A%2F%2Fmaps.google.com%2F%3Fq%3D37.7749%2C-122.4194
    try {
      const url = new URL(link);
      const params = new URLSearchParams(url.search);
      const mapUrl = params.get('url');
      
      if (mapUrl) {
        const decodedUrl = decodeURIComponent(mapUrl);
        const coordsMatch = decodedUrl.match(/q=(-?\d+\.\d+),(-?\d+\.\d+)/);
        
        if (coordsMatch) {
          return [coordsMatch[1], coordsMatch[2]];
        }
      }
      
      return null;
    } catch (e) {
      console.error('Invalid URL:', e);
      return null;
    }
  };
  
  // Handle inserting the location
  const handleInsertLocation = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    let locationData: LocationData | null = null;
    
    // Get location data based on the active tab
    if (locationTab === 'coordinates') {
      if (!lat || !lng) return;
      
      locationData = {
        lat: parseFloat(lat),
        lng: parseFloat(lng),
        source: 'coordinates'
      };
    } else if (locationTab === 'telegram') {
      const coords = extractCoordinatesFromTelegram(telegramLink);
      if (!coords) return;
      
      locationData = {
        lat: parseFloat(coords[0]),
        lng: parseFloat(coords[1]),
        source: 'telegram'
      };
    }
    
    if (!locationData) return;
    
    // Create location element
    const locationElement = document.createElement('div');
    locationElement.className = 'location-element';
    locationElement.style.border = '1px solid #ddd';
    locationElement.style.borderRadius = '4px';
    locationElement.style.padding = '8px';
    locationElement.style.margin = '10px 0';
    locationElement.style.backgroundColor = '#f9f9f9';
    
    // Create location content with Google Maps static image
    const locationImg = document.createElement('img');
    locationImg.src = `https://maps.googleapis.com/maps/api/staticmap?center=${locationData.lat},${locationData.lng}&zoom=14&size=600x300&markers=color:red%7C${locationData.lat},${locationData.lng}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ""}`;
    locationImg.alt = 'Location Map';
    locationImg.style.width = '100%';
    locationImg.style.maxHeight = '150px';
    locationImg.style.objectFit = 'cover';
    
    const locationText = document.createElement('div');
    locationText.textContent = `الموقع: ${locationData.lat}, ${locationData.lng}`;
    locationText.style.marginTop = '5px';
    locationText.style.fontSize = '12px';
    locationText.dir = 'rtl';
    
    locationElement.appendChild(locationImg);
    locationElement.appendChild(locationText);
    
    // Store location data
    locationElement.dataset.location = JSON.stringify(locationData);
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert the location at cursor position
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(locationElement);
    } else {
      editor.appendChild(locationElement);
    }
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
    
    // Reset and close the modal
    resetForm();
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) onClose();
      if (open) resetForm();
    }}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-right">إدراج موقع</DialogTitle>
        </DialogHeader>
        
        <Tabs value={locationTab} onValueChange={setLocationTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="coordinates">إحداثيات</TabsTrigger>
            <TabsTrigger value="telegram">رابط تليجرام</TabsTrigger>
          </TabsList>
          
          <TabsContent value="coordinates" className="py-4">
            <div className="grid gap-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="lat" className="text-right col-span-1">
                  خط العرض
                </Label>
                <Input
                  id="lat"
                  type="text"
                  value={lat}
                  onChange={(e) => setLat(e.target.value)}
                  placeholder="مثال: 24.774265"
                  className="col-span-3"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="lng" className="text-right col-span-1">
                  خط الطول
                </Label>
                <Input
                  id="lng"
                  type="text"
                  value={lng}
                  onChange={(e) => setLng(e.target.value)}
                  placeholder="مثال: 46.738586"
                  className="col-span-3"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="telegram" className="py-4">
            <div className="grid gap-4">
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="telegramLink" className="text-right">
                  رابط تليجرام
                </Label>
                <Input
                  id="telegramLink"
                  type="text"
                  value={telegramLink}
                  onChange={(e) => setTelegramLink(e.target.value)}
                  placeholder="أدخل رابط الموقع من تليجرام"
                  dir="ltr"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="sm:justify-start">
          <div className="flex flex-row-reverse w-full justify-start gap-2">
            <Button type="submit" onClick={handleInsertLocation}>إدراج</Button>
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
