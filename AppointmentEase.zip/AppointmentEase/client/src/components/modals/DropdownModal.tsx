import { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useEditor } from '@/contexts/EditorContext';

interface DropdownModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DropdownModal({ isOpen, onClose }: DropdownModalProps) {
  const [dropdownValues, setDropdownValues] = useState('');
  const { state, dispatch } = useEditor();
  
  // Handle creating the dropdown
  const handleCreateDropdown = () => {
    const editor = document.getElementById('documentEditor');
    if (!editor || !state.currentDocument) return;
    
    // Get the values
    const values = dropdownValues.split('\n')
      .filter(value => value.trim() !== '');
    
    if (values.length === 0) {
      // Show error or toast
      return;
    }
    
    // Create select element
    const select = document.createElement('select');
    select.className = 'cell-dropdown';
    
    // Add options
    values.forEach(value => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = value;
      select.appendChild(option);
    });
    
    // Save current content to undo stack
    dispatch({ 
      type: 'ADD_TO_UNDO_STACK', 
      payload: state.currentDocument.content 
    });
    
    // Insert the dropdown at cursor position
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(select);
    } else {
      // Find the first table cell and append to it
      const cell = editor.querySelector('td');
      if (cell) {
        cell.appendChild(select);
      } else {
        editor.appendChild(select);
      }
    }
    
    // Update document content
    dispatch({ 
      type: 'UPDATE_DOCUMENT_CONTENT', 
      payload: editor.innerHTML 
    });
    
    // Reset and close the modal
    setDropdownValues('');
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-right">إدراج قائمة منسدلة</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-1 gap-2">
            <Label htmlFor="dropdownValues" className="text-right">
              قيم القائمة (كل قيمة في سطر)
            </Label>
            <Textarea
              id="dropdownValues"
              rows={5}
              value={dropdownValues}
              onChange={(e) => setDropdownValues(e.target.value)}
              placeholder="قيمة 1&#10;قيمة 2&#10;قيمة 3"
              dir="rtl"
            />
          </div>
        </div>
        
        <DialogFooter className="sm:justify-start">
          <div className="flex flex-row-reverse w-full justify-start gap-2">
            <Button type="submit" onClick={handleCreateDropdown}>إدراج</Button>
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
